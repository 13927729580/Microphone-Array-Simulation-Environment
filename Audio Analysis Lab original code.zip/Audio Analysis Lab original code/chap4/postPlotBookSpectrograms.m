clc;clear all;close all;

addpath([cd,'\..\data\']);

[speech,sampFreq] = audioread('twoMaleTwoFemale20Seconds.wav');
[babble] = audioread('babble30Seconds.wav');
[exhib] = audioread('exhibition30Seconds.wav');
[street] = audioread('street30Seconds.wav');
[car] = audioread('car30Seconds.wav');

timeLimit = 5;
timeNdxLimit = round(sampFreq*timeLimit);

nWin = 512;
nOverlap = 300;
nFft = 2048;
[speechSpec,freqSpec,timeSpec,speechPsd] = spectrogram(speech(1:timeNdxLimit),...
    nWin,nOverlap,nFft,sampFreq);

[babbleSpec,~,~,babblePsd] = spectrogram(babble(1:timeNdxLimit),...
    nWin,nOverlap,nFft,sampFreq);

[exhibSpec,~,~,exhibPsd] = spectrogram(exhib(1:timeNdxLimit),...
    nWin,nOverlap,nFft,sampFreq);

[streetSpec,~,~,streetPsd] = spectrogram(street(1:timeNdxLimit),...
    nWin,nOverlap,nFft,sampFreq);

[carSpec,~,~,carPsd] = spectrogram(speech(1:timeNdxLimit),...
    nWin,nOverlap,nFft,sampFreq);

%%

timeT = (1:timeNdxLimit)/sampFreq;

h1 = figure(1);
h1.Position = [834 456 574 582];
subplot(2,1,1);
plot(timeT,speech(1:timeNdxLimit));
grid on;
xlim([0.1,4.9]);

xlabel('Time [s]');
ylabel('Amplitude');

subplot(2,1,2);
handleIm = imagesc(timeSpec,freqSpec,20*log10(abs(speechSpec)));
view([0,-90]);
xlim([0.1,4.9]);

hCb1 = colorbar;
hCb1.Position = [0.8574 0.1100 0.0465 0.3412];

xlabel('Time [s]');
ylabel('Frequency [Hz]');

h2 = figure(2);
h2.Position = [834 433 1015 605];
subplot(2,2,1);
handleImBabble = imagesc(timeSpec,freqSpec,20*log10(abs(babbleSpec)));
view([0,-90]);
xlim([0.1,4.9]);

hCb2a = colorbar;
hCb2a.Position = [0.4642 0.5838 0.0258 0.3412];

title('(a)');
xlabel('Time [s]');
ylabel('Frequency [Hz]');

subplot(2,2,2);
handleImExhib = imagesc(timeSpec,freqSpec,20*log10(abs(exhibSpec)));
view([0,-90]);
xlim([0.1,4.9]);

hCb2b = colorbar;
hCb2b.Position = [0.9047 0.5838 0.0262 0.3412];

title('(b)');
xlabel('Time [s]');
ylabel('Frequency [Hz]');

subplot(2,2,3);
handleImStreet = imagesc(timeSpec,freqSpec,20*log10(abs(streetSpec)));
view([0,-90]);
xlim([0.1,4.9]);

hCb2c = colorbar;
hCb2c.Position = [0.4642 0.1100 0.0282 0.3412];

title('(c)');
xlabel('Time [s]');
ylabel('Frequency [Hz]');

subplot(2,2,4);
handleImCar = imagesc(timeSpec,freqSpec,20*log10(abs(carSpec)));
view([0,-90]);
xlim([0.1,4.9]);

hCb2d = colorbar;
hCb2d.Position = [0.9047 0.1100 0.0262 0.3412];

title('(d)');
xlabel('Time [s]');
ylabel('Frequency [Hz]');


