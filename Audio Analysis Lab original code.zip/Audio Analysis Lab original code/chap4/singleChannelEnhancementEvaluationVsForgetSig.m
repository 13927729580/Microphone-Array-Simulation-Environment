clc;clear all;close all;

addpath([cd,'\..\data\']);
addpath([cd,'\..\functions\']);

nWin = 50;
nFft = 64;

iSnr = 0;

nFilt = 4;

filtSetups.minDis.signalRanks = 2:(nFilt-1);

forgetNoi = 0.99;
forgetSigGrid = 0.91:0.02:0.99;

signalString = 'twoMaleTwoFemale20Seconds.wav';
noiseStrings = {'babble30Seconds.wav','exhibition30Seconds.wav','street30Seconds.wav','car30Seconds.wav'};
filtStrings = {'maxSnr','minDis','wiener'};

display(['Running script: ',mfilename]);
display(' ');
for iNoise = 1:length(noiseStrings),
    noiseString = char(noiseStrings(iNoise));
    display(['Noise scenario: ',noiseString,' (',num2str(iNoise),' of ',num2str(length(noiseStrings)),')']);
    display('   Enhancing...');
    for idx = 1:length(forgetSigGrid),
        display(['      iter #: ',num2str(idx),' of ',num2str(length(forgetSigGrid))]);
        forgetSig = forgetSigGrid(idx);

        enhancedData = stftEnhanceSignals(signalString,noiseString,iSnr,nFft,nWin,nFilt,forgetSig,forgetNoi,filtStrings,filtSetups);

        performance(idx,iNoise) = stftMeasurePerformance(enhancedData,filtStrings,1);

        setup(idx,iNoise) = enhancedData.setup;
    end

    display('   Measuring performance...');
    for idx = 1:length(forgetSigGrid),
        iSnrFbMean(1,idx,iNoise) = performance(idx,iNoise).noiseReduction.iSnr.fbMean;
        oSnrMaxSnrFbMean(1,idx,iNoise) = performance(idx,iNoise).noiseReduction.oSnr.maxSnr.fbMean;
        oSnrWienerFbMean(1,idx,iNoise) = performance(idx,iNoise).noiseReduction.oSnr.wiener.fbMean;
        oSnrMinDisFbMean(:,idx,iNoise) = squeeze(performance(idx,iNoise).noiseReduction.oSnr.minDis.fbMean);

        dsdMaxSnrFbMean(1,idx,iNoise) = performance(idx,iNoise).signalDistortion.dsd.maxSnr.fbMean;
        dsdWienerFbMean(1,idx,iNoise) = performance(idx,iNoise).signalDistortion.dsd.wiener.fbMean;
        dsdMinDisFbMean(:,idx,iNoise) = squeeze(performance(idx,iNoise).signalDistortion.dsd.minDis.fbMean);
    end
end

%% plots
close all;

figure(1);
plot(10*log10(mean(iSnrFbMean,3)),'k');
hold on;
plot(10*log10(mean(oSnrMaxSnrFbMean,3)));
plot(10*log10(mean(oSnrWienerFbMean,3)));
plot(10*log10(mean(oSnrMinDisFbMean,3).'),'g');
hold off;

figure(2);
semilogy(10*log10(mean(dsdMaxSnrFbMean,3)));
hold on;
semilogy(10*log10(mean(dsdWienerFbMean,3)));
semilogy(10*log10(mean(dsdMinDisFbMean,3).'),'g');
hold off;

%% save

% dateString = datestr(now,30);
% save([mfilename,'_',dateString,'.mat']);
