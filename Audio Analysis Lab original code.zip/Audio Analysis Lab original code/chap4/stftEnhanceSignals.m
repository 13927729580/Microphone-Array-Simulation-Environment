function [data] = stftEnhanceSignals(signalString,noiseString,iSnr,nFft,nWin,nFilt,forgetSig,forgetNoi,filtStrings,filtSetups)

[signal,freqSamp] = audioread(signalString);

[noise,freqSampNoise] = audioread(noiseString);

if freqSamp~=freqSampNoise,
    error('The signal and noise are not sampled at the same frequency.');
end
if length(noise)<length(signal),
    error('Signal vector is longer than noise vector.');
end

noise = noise(1:length(signal));

% change noise power to get desired snr
sigPow = var(signal);
noiPow = sigPow/10^(iSnr/10);
noise = sqrt(noiPow)*noise/std(noise);

% generate observation
observed = signal + noise;

% apply stft
[data.raw.sigStft,freqGrid,timeGrid,data.raw.sigBlocks] = stftBatch(signal,nWin,nFft,freqSamp);
[data.raw.noiStft,~,~,data.raw.noiBlocks] = stftBatch(noise,nWin,nFft,freqSamp);
[data.raw.obsStft,~,~,data.raw.obsBlocks] = stftBatch(observed,nWin,nFft,freqSamp);

[nFreqs,nFrames] = size(data.raw.sigStft);

% inits
noiCorr = repmat(eye(nFilt),1,1,nFreqs);
obsCorr = repmat(eye(nFilt),1,1,nFreqs);
sigCorr = repmat(eye(nFilt),1,1,nFreqs);
geigVec = zeros(nFilt,nFilt,nFreqs);
geigVal = zeros(nFilt,nFilt,nFreqs);
for iFiltStrs = 1:length(filtStrings),
    switch char(filtStrings(iFiltStrs)),
        case 'maxSnr',
        hMaxSnr = zeros(nFilt,nFreqs);
        data.maxSnr.sigStft = zeros(nFreqs,nFrames);
        data.maxSnr.noiStft = zeros(nFreqs,nFrames);
        data.maxSnr.obsStft = zeros(nFreqs,nFrames);
        case 'wiener',
        hWiener = zeros(nFilt,nFreqs);
        data.wiener.sigStft = zeros(nFreqs,nFrames);
        data.wiener.noiStft = zeros(nFreqs,nFrames);
        data.wiener.obsStft = zeros(nFreqs,nFrames);
        case 'minDis', 
        hMinDis = zeros(nFilt,nFreqs,length(filtSetups.minDis.signalRanks));
        data.minDis.sigStft = zeros(nFreqs,nFrames,length(filtSetups.minDis.signalRanks));
        data.minDis.noiStft = zeros(nFreqs,nFrames,length(filtSetups.minDis.signalRanks));
        data.minDis.obsStft = zeros(nFreqs,nFrames,length(filtSetups.minDis.signalRanks));
        case 'trOff', 
        hTrOff = zeros(nFilt,nFreqs,length(filtSetups.trOff.signalRanks));
        data.trOff.sigStft = zeros(nFreqs,nFrames,length(filtSetups.trOff.signalRanks));
        data.trOff.noiStft = zeros(nFreqs,nFrames,length(filtSetups.trOff.signalRanks));
        data.trOff.obsStft = zeros(nFreqs,nFrames,length(filtSetups.trOff.signalRanks));
    end
end
for iFrame=1:nFrames,
    for iFreq=1:nFreqs,
        % extract blocks from signal, noise and observation
        if iFrame<nFilt,
            noiBlock = [data.raw.noiStft(iFreq,iFrame:-1:1).';zeros(nFilt-iFrame,1)];
            sigBlock = [data.raw.sigStft(iFreq,iFrame:-1:1).';zeros(nFilt-iFrame,1)];
            obsBlock = [data.raw.obsStft(iFreq,iFrame:-1:1).';zeros(nFilt-iFrame,1)];
        else
            noiBlock = data.raw.noiStft(iFreq,iFrame:-1:iFrame-nFilt+1).';
            sigBlock = data.raw.sigStft(iFreq,iFrame:-1:iFrame-nFilt+1).';
            obsBlock = data.raw.obsStft(iFreq,iFrame:-1:iFrame-nFilt+1).';
        end        
        
        % estimate statistics
        noiCorr(:,:,iFreq) = (1-forgetNoi)*noiCorr(:,:,iFreq) + (forgetNoi)*(noiBlock*noiBlock');
        obsCorr(:,:,iFreq) = (1-forgetSig)*obsCorr(:,:,iFreq) + (forgetSig)*(obsBlock*obsBlock');
        sigCorr(:,:,iFreq) = (1-forgetSig)*sigCorr(:,:,iFreq) + (forgetSig)*(sigBlock*sigBlock');
        
        for iFilt = 1:nFilt,
            noiCorr(iFilt,iFilt,iFreq) = real(noiCorr(iFilt,iFilt,iFreq));
            obsCorr(iFilt,iFilt,iFreq) = real(obsCorr(iFilt,iFilt,iFreq));
            sigCorr(iFilt,iFilt,iFreq) = real(sigCorr(iFilt,iFilt,iFreq));
        end  
        
        % save power
        data.raw.sigPow(iFreq,iFrame) = real(sigCorr(1,1,iFreq));
        data.raw.noiPow(iFreq,iFrame) = real(noiCorr(1,1,iFreq));
        data.raw.obsPow(iFreq,iFrame) = real(obsCorr(1,1,iFreq));
        
        % joint diagonalization
        [geigVec(:,:,iFreq),geigVal(:,:,iFreq)] = jeig(sigCorr(:,:,iFreq),...
            noiCorr(:,:,iFreq),1);
        
        for iFiltStr=1:length(filtStrings),
            switch char(filtStrings(iFiltStr)),
                case 'maxSnr',
                % max snr filt
                hMaxSnr(:,iFreq) = (geigVec(:,1,iFreq)*geigVec(:,1,iFreq)')/geigVal(1,1,iFreq)*sigCorr(:,1,iFreq);
                if norm(hMaxSnr(:,iFreq))==0,
                    hMaxSnr(:,iFreq) = eye(nFilt,1);
                end                
                data.maxSnr.sigStft(iFreq,iFrame) = hMaxSnr(:,iFreq)'*sigBlock;
                data.maxSnr.noiStft(iFreq,iFrame) = hMaxSnr(:,iFreq)'*noiBlock;
                data.maxSnr.obsStft(iFreq,iFrame) = hMaxSnr(:,iFreq)'*obsBlock;
                data.maxSnr.sigPow(iFreq,iFrame) = real(hMaxSnr(:,iFreq)'*sigCorr(:,:,iFreq)*hMaxSnr(:,iFreq));
                data.maxSnr.noiPow(iFreq,iFrame) = real(hMaxSnr(:,iFreq)'*noiCorr(:,:,iFreq)*hMaxSnr(:,iFreq));
                data.maxSnr.obsPow(iFreq,iFrame) = real(hMaxSnr(:,iFreq)'*obsCorr(:,:,iFreq)*hMaxSnr(:,iFreq));
                
                case 'wiener',
                % wiener filt
                blbSubW = zeros(nFilt);
                for iFilt = 1:nFilt,
                    blbSubW = blbSubW + (geigVec(:,iFilt,iFreq)*geigVec(:,iFilt,iFreq)')...
                        /(1+geigVal(iFilt,iFilt,iFreq));
                end
                hWiener(:,iFreq) = blbSubW*sigCorr(:,1,iFreq);
                if norm(hWiener(:,iFreq))==0,
                    hWiener(:,iFreq) = eye(nFilt,1);
                end
                data.wiener.sigStft(iFreq,iFrame) = hWiener(:,iFreq)'*sigBlock;
                data.wiener.noiStft(iFreq,iFrame) = hWiener(:,iFreq)'*noiBlock;
                data.wiener.obsStft(iFreq,iFrame) = hWiener(:,iFreq)'*obsBlock;
                data.wiener.sigPow(iFreq,iFrame) = real(hWiener(:,iFreq)'*sigCorr(:,:,iFreq)*hWiener(:,iFreq));
                data.wiener.noiPow(iFreq,iFrame) = real(hWiener(:,iFreq)'*noiCorr(:,:,iFreq)*hWiener(:,iFreq));
                data.wiener.obsPow(iFreq,iFrame) = real(hWiener(:,iFreq)'*obsCorr(:,:,iFreq)*hWiener(:,iFreq));

                case 'minDis',
                % minimum dist filt
                blbSub = zeros(nFilt);
                iterRanks = 1;
                for iRanks = 1:max(filtSetups.minDis.signalRanks),
                    blbSub = blbSub + (geigVec(:,iRanks,iFreq)*geigVec(:,iRanks,iFreq)')/geigVal(iRanks,iRanks,iFreq);
                    if sum(iRanks==filtSetups.minDis.signalRanks),
                        hMinDis(:,iFreq,iterRanks) = blbSub*sigCorr(:,1,iFreq);
                        if norm(hMinDis(:,iFreq,iterRanks))==0,
                            hMinDis(:,iFreq,iterRanks) = eye(nFilt,1);
                        end
                        iterRanks = iterRanks + 1;
                    end
                end
                for iRanks=1:length(filtSetups.minDis.signalRanks),
                    data.minDis.sigStft(iFreq,iFrame,iRanks) = hMinDis(:,iFreq,iRanks)'*sigBlock;
                    data.minDis.noiStft(iFreq,iFrame,iRanks) = hMinDis(:,iFreq,iRanks)'*noiBlock;
                    data.minDis.obsStft(iFreq,iFrame,iRanks) = hMinDis(:,iFreq,iRanks)'*obsBlock;
                    data.minDis.sigPow(iFreq,iFrame,iRanks) = real(hMinDis(:,iFreq,iRanks)'*sigCorr(:,:,iFreq)*hMinDis(:,iFreq,iRanks));
                    data.minDis.noiPow(iFreq,iFrame,iRanks) = real(hMinDis(:,iFreq,iRanks)'*noiCorr(:,:,iFreq)*hMinDis(:,iFreq,iRanks));
                    data.minDis.obsPow(iFreq,iFrame,iRanks) = real(hMinDis(:,iFreq,iRanks)'*obsCorr(:,:,iFreq)*hMinDis(:,iFreq,iRanks));
                end
                
                case 'trOff',
                % trade off filt
                blbSub = zeros(nFilt);
                iterRanks = 1;
                for iRanks = 1:max(filtSetups.trOff.signalRanks),
                    blbSub = blbSub + (geigVec(:,iRanks,iFreq)*geigVec(:,iRanks,iFreq)')/(filtSetups.trOff.mu+geigVal(iRanks,iRanks,iFreq));
                    if sum(iRanks==filtSetups.trOff.signalRanks),
                        hTrOff(:,iFreq,iterRanks) = blbSub*sigCorr(:,1,iFreq);
                        if norm(hTrOff(:,iFreq,iterRanks))==0,
                            hTrOff(:,iFreq,iterRanks) = eye(nFilt,1);
                        end
                        iterRanks = iterRanks + 1;
                    end
                end
                for iRanks=1:length(filtSetups.trOff.signalRanks),
                    data.trOff.sigStft(iFreq,iFrame,iRanks) = hTrOff(:,iFreq,iRanks)'*sigBlock;
                    data.trOff.noiStft(iFreq,iFrame,iRanks) = hTrOff(:,iFreq,iRanks)'*noiBlock;
                    data.trOff.obsStft(iFreq,iFrame,iRanks) = hTrOff(:,iFreq,iRanks)'*obsBlock;
                    data.trOff.sigPow(iFreq,iFrame,iRanks) = real(hTrOff(:,iFreq,iRanks)'*sigCorr(:,:,iFreq)*hTrOff(:,iFreq,iRanks));
                    data.trOff.noiPow(iFreq,iFrame,iRanks) = real(hTrOff(:,iFreq,iRanks)'*noiCorr(:,:,iFreq)*hTrOff(:,iFreq,iRanks));
                    data.trOff.obsPow(iFreq,iFrame,iRanks) = real(hTrOff(:,iFreq,iRanks)'*obsCorr(:,:,iFreq)*hTrOff(:,iFreq,iRanks));
                end
            end
        end
    end
end

for iFiltStr=1:length(filtStrings),
    switch char(filtStrings(iFiltStr)),
        case 'maxSnr',
        % stft to time
        data.maxSnr.sig = stftInvBatch(data.maxSnr.sigStft,nWin,nFft);
        data.maxSnr.noi = stftInvBatch(data.maxSnr.noiStft,nWin,nFft);
        data.maxSnr.obs = stftInvBatch(data.maxSnr.obsStft,nWin,nFft);

        case 'wiener',
        data.wiener.sig = stftInvBatch(data.wiener.sigStft,nWin,nFft);
        data.wiener.noi = stftInvBatch(data.wiener.noiStft,nWin,nFft);
        data.wiener.obs = stftInvBatch(data.wiener.obsStft,nWin,nFft);

        case 'minDis',
        for iRanks=1:length(filtSetups.minDis.signalRanks),
            data.minDis.sig(:,iRanks) = stftInvBatch(data.minDis.sigStft(:,:,iRanks),nWin,nFft);
            data.minDis.noi(:,iRanks) = stftInvBatch(data.minDis.noiStft(:,:,iRanks),nWin,nFft);
            data.minDis.obs(:,iRanks) = stftInvBatch(data.minDis.obsStft(:,:,iRanks),nWin,nFft);
        end
        % save to struct
        data.minDis.signalRanks = filtSetups.minDis.signalRanks;
        
        case 'trOff',
        for iRanks=1:length(filtSetups.trOff.signalRanks),
            data.trOff.sig(:,iRanks) = stftInvBatch(data.trOff.sigStft(:,:,iRanks),nWin,nFft);
            data.trOff.noi(:,iRanks) = stftInvBatch(data.trOff.noiStft(:,:,iRanks),nWin,nFft);
            data.trOff.obs(:,iRanks) = stftInvBatch(data.trOff.obsStft(:,:,iRanks),nWin,nFft);
        end
        % save to struct
        data.trOff.signalRanks = filtSetups.trOff.signalRanks;
    end
end

% save setup
data.setup.stftFreqGrid = freqGrid;
data.setup.stftTimeGrid = timeGrid;
data.setup.freqSamp = freqSamp;
data.setup.nWin = nWin;
data.setup.nFft = nFft;

% save raw signals
data.raw.sig = signal;
data.raw.noi = noise;
data.raw.obs = observed;