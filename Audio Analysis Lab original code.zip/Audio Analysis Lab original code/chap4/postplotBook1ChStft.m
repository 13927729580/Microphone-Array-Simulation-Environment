clc;clear all;close all;

set(0,'DefaultAxesFontName','Times');
set(0,'DefaultAxesFontSize',10);

%% load data to plot

dataVsFiltLenStr = 'singleChannelEnhancementEvaluationVsFiltLen_20141216T120731.mat';
dataVsForgetNoiStr = 'singleChannelEnhancementEvaluationVsForgetNoi_20141216T112900.mat';
dataVsForgetSigStr = 'singleChannelEnhancementEvaluationVsForgetSig_20141216T112907.mat';
dataVsSnrStr = 'singleChannelEnhancementEvaluationVsSnr_20141216T135825.mat';
dataVsTradeOffStr = 'singleChannelEnhancementEvaluationVsTradeoff_20141216T113837.mat';
dataVsWinLenStr = 'singleChannelEnhancementEvaluationVsWinLen_20141216T115430.mat';

%% plot results versus filter length
data = load(dataVsFiltLenStr);

h2 = figure(2);
h2.Position = [316 685 569 653];

h2s1 = subplot(2,1,1);
plot(data.nFiltGrid,10*log10(mean(data.iSnrFbMean,3)),'k--','LineWidth',1);
hold on;
plot(data.nFiltGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'bx-','LineWidth',1);
plot(data.nFiltGrid,10*log10(mean(data.oSnrWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.nFiltGrid,10*log10(mean(data.oSnrMinDisFbMean,3).'),'gs-','LineWidth',1);
plot(data.nFiltGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'b-','LineWidth',1);
plot(data.nFiltGrid,10*log10(mean(data.oSnrMinDisFbMean,3).'),'g--','LineWidth',1);
hold off;
grid on;

h2s1.XTick = data.nFiltGrid;

xlabel('Filter length');
ylabel('Output SNR [dB]');

legend('iSNR','Max SNR','Wiener','Min Dis','Location','NorthWest');

for ii = 1:length(data.nFiltGrid),
    tmp = 10*log10(mean(data.oSnrMinDisFbMean,3));
    hT = text(data.nFiltGrid(max([2,ii])),tmp(ii,max([2,ii])),...
        ['{\it Q} = ',num2str(data.nFiltGrid(ii))],...
        'FontName','Times','VerticalAlignment','bottom',...
        'HorizontalAlignment','right');
end

h2s2 = subplot(2,1,2);
semilogy(data.nFiltGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
semilogy(data.nFiltGrid,10*log10(mean(data.dsdWienerFbMean,3)),'r*-','LineWidth',1);
semilogy(data.nFiltGrid,10*log10(mean(data.dsdMinDisFbMean,3).'),'gs-','LineWidth',1);
semilogy(data.nFiltGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'b-','LineWidth',1);
semilogy(data.nFiltGrid,10*log10(mean(data.dsdMinDisFbMean,3).'),'g--','LineWidth',1);
hold off;
grid on;

h2s2.XTick = data.nFiltGrid;

xlabel('Filter length');
ylabel('Signal reduction factor [dB]');

legend('Max SNR','Wiener','Min Dis');

for ii = 1:length(data.nFiltGrid),
    tmp = 10*log10(mean(data.dsdMinDisFbMean,3));
    hT = text(data.nFiltGrid(max([2,ii])),tmp(ii,max([2,ii])),...
        ['{\it Q} = ',num2str(data.nFiltGrid(ii))],...
        'FontName','Times','VerticalAlignment','bottom',...
        'HorizontalAlignment','right');
end

%% plot results versus noise forgetting factor
data = load(dataVsForgetNoiStr);

h3 = figure(3);
h3.Position = [316 685 569 653];
subplot(2,1,1);
plot(data.forgetNoiGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.forgetNoiGrid,10*log10(mean(data.oSnrWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.forgetNoiGrid,10*log10(mean(data.oSnrMinDisFbMean,3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Noise forgetting factor');
ylabel('Output SNR [dB]');

legend('Max. SNR','Wiener','Min. dis.','Location','NorthWest');

for ii = 1:length(data.filtSetups.minDis.signalRanks),
    hT = text(data.forgetNoiGrid(2),10*log10(mean(data.oSnrMinDisFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.filtSetups.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment','bottom');
end

subplot(2,1,2);
semilogy(data.forgetNoiGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
semilogy(data.forgetNoiGrid,10*log10(mean(data.dsdWienerFbMean,3)),'r*-','LineWidth',1);
semilogy(data.forgetNoiGrid,10*log10(mean(data.dsdMinDisFbMean,3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Noise forgetting factor');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','Min. dis.');

for ii = 1:length(data.filtSetups.minDis.signalRanks),
    hT = text(data.forgetNoiGrid(2),10*log10(mean(data.dsdMinDisFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.filtSetups.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment','bottom');
end

%% plot results versus signal forgetting factor
data = load(dataVsForgetSigStr);

h4 = figure(4);
h4.Position = [316 685 569 653];
subplot(2,1,1);
plot(data.forgetSigGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.forgetSigGrid,10*log10(mean(data.oSnrWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.forgetSigGrid,10*log10(mean(data.oSnrMinDisFbMean,3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Signal forgetting factor');
ylabel('Output SNR [dB]');

legend('Max. SNR','Wiener','Min. dis.');

for ii = 1:length(data.filtSetups.minDis.signalRanks),
    hT = text(data.forgetSigGrid(2),10*log10(mean(data.oSnrMinDisFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.filtSetups.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment','bottom');
end

subplot(2,1,2);
semilogy(data.forgetSigGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
semilogy(data.forgetSigGrid,10*log10(mean(data.dsdWienerFbMean,3)),'r*-','LineWidth',1);
semilogy(data.forgetSigGrid,10*log10(mean(data.dsdMinDisFbMean,3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Signal forgetting factor');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','Min. dis.','Location','SouthWest');

for ii = 1:length(data.filtSetups.minDis.signalRanks),
    hT = text(data.forgetSigGrid(2),10*log10(mean(data.dsdMinDisFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.filtSetups.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment','bottom');
end

%% plot results versus signal to noise ratio
data = load(dataVsSnrStr);

h5 = figure(5);
h5.Position = [316 685 569 653];
subplot(2,1,1);
plot(data.iSnrGrid,10*log10(mean(data.iSnrFbMean,3)),'k--','LineWidth',1);
hold on;
plot(data.iSnrGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'bx-','LineWidth',1);
plot(data.iSnrGrid,10*log10(mean(data.oSnrWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.iSnrGrid,10*log10(mean(data.oSnrMinDisFbMean,3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Input SNR [dB]');
ylabel('Output SNR [dB]');

legend('iSNR','Max. SNR','Wiener','Min. dis.');

for ii = 1:length(data.filtSetups.minDis.signalRanks),
    hT = text(data.iSnrGrid(2),10*log10(mean(data.oSnrMinDisFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.filtSetups.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment','bottom');
end

subplot(2,1,2);
semilogy(data.iSnrGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
semilogy(data.iSnrGrid,10*log10(mean(data.dsdWienerFbMean,3)),'r*-','LineWidth',1);
semilogy(data.iSnrGrid,10*log10(mean(data.dsdMinDisFbMean,3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Input SNR [dB]');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','Min. dis.');

for ii = 1:length(data.filtSetups.minDis.signalRanks),
    hT = text(data.iSnrGrid(2),10*log10(mean(data.dsdMinDisFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.filtSetups.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment','bottom');
end

%% plot results versus trade off parameter, \mu
data = load(dataVsTradeOffStr);

h6 = figure(6);
h6.Position = [316 685 569 653];
subplot(2,1,1);
plot(data.muGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.muGrid,10*log10(mean(data.oSnrWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.muGrid,10*log10(mean(data.oSnrTrOffFbMean(1:3,:,:),3).'),'co-','LineWidth',1);
plot(data.muGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'b-','LineWidth',1);
plot(data.muGrid,10*log10(mean(data.oSnrTrOffFbMean(1,:,:),3).'),'c--','LineWidth',1);
hold off;
grid on;
xlim([min(data.muGrid),max(data.muGrid)]);

xlabel('Tradeoff parameter');
ylabel('Output SNR [dB]');

legend('Max. SNR','Wiener','Tradeoff','Location','SouthEast');

for ii = 1:length(data.filtSetups.trOff.signalRanks)-1,
    hT = text(data.muGrid(2),10*log10(mean(data.oSnrTrOffFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.filtSetups.trOff.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment','bottom');
end

subplot(2,1,2);
semilogy(data.muGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
semilogy(data.muGrid,10*log10(mean(data.dsdWienerFbMean,3)),'r*-','LineWidth',1);
semilogy(data.muGrid,10*log10(mean(data.dsdTrOffFbMean(1:3,:,:),3).'),'co-','LineWidth',1);
semilogy(data.muGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'b-','LineWidth',1);
semilogy(data.muGrid,10*log10(mean(data.dsdTrOffFbMean(1,:,:),3).'),'c--','LineWidth',1);
hold off;
grid on;
xlim([min(data.muGrid),max(data.muGrid)]);
ylim([1e-4,1e0]);

xlabel('Tradeoff parameter');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','Tradeoff','Location','SouthEast');

for ii = 1:length(data.filtSetups.trOff.signalRanks)-1,
    hT = text(data.muGrid(2),10*log10(mean(data.dsdTrOffFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.filtSetups.trOff.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment','bottom');
end

%% plot results versus window length used in stft
data = load(dataVsWinLenStr);

h7 = figure(7);
h7.Position = [316 685 569 653];
subplot(2,1,1);
plot(data.nWinGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.nWinGrid,10*log10(mean(data.oSnrWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.nWinGrid,10*log10(mean(data.oSnrMinDisFbMean,3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Window length');
ylabel('Output SNR [dB]');

legend('Max. SNR','Wiener','Min. dis.');

for ii = 1:length(data.filtSetups.minDis.signalRanks),
    hT = text(data.nWinGrid(2),10*log10(mean(data.oSnrMinDisFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.filtSetups.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment','bottom');
end

subplot(2,1,2);
semilogy(data.nWinGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
semilogy(data.nWinGrid,10*log10(mean(data.dsdWienerFbMean,3)),'r*-','LineWidth',1);
semilogy(data.nWinGrid,10*log10(mean(data.dsdMinDisFbMean,3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Window length');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','Min. dis.');

for ii = 1:length(data.filtSetups.minDis.signalRanks),
    hT = text(data.nWinGrid(2),10*log10(mean(data.dsdMinDisFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.filtSetups.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment','bottom');
end
