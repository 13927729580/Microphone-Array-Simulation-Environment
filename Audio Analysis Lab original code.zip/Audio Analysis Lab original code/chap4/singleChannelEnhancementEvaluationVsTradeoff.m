clc;clear all;close all;

addpath([cd,'\..\data\']);
addpath([cd,'\..\functions\']);

nWin = 50;
nFft = 2^nextpow2(nWin);

nFilt = 4;

muGrid = 0:0.25:1.25;
filtSetups.trOff.signalRanks = 1:nFilt;
iSnr = 0;

forgetNoi = 0.99;
forgetSig = 0.95;

signalString = 'twoMaleTwoFemale20Seconds.wav';
noiseStrings = {'babble30Seconds.wav','exhibition30Seconds.wav','street30Seconds.wav','car30Seconds.wav'};
filtStrings = {'maxSnr','trOff','wiener'};

display(['Running script: ',mfilename]);
display(' ');
for iNoise = 1:length(noiseStrings),
    noiseString = char(noiseStrings(iNoise));
    display(['Noise scenario: ',noiseString,' (',num2str(iNoise),' of ',num2str(length(noiseStrings)),')']);
    display('Enhancing...');
    for idx = 1:length(muGrid),
        display(['   iter #: ',num2str(idx),' of ',num2str(length(muGrid))]);
        filtSetups.trOff.mu = muGrid(idx);

        enhancedData = stftEnhanceSignals(signalString,noiseString,iSnr,nFft,nWin,nFilt,forgetSig,forgetNoi,filtStrings,filtSetups);

        performance(idx,iNoise) = stftMeasurePerformance(enhancedData,filtStrings,1);
    end

    display('Measuring performance...');
    for idx = 1:length(muGrid),
        iSnrFbMean(1,idx,iNoise) = performance(idx,iNoise).noiseReduction.iSnr.fbMean;
        oSnrMaxSnrFbMean(1,idx,iNoise) = performance(idx,iNoise).noiseReduction.oSnr.maxSnr.fbMean;
        oSnrWienerFbMean(1,idx,iNoise) = performance(idx,iNoise).noiseReduction.oSnr.wiener.fbMean;
        oSnrTrOffFbMean(:,idx,iNoise) = squeeze(performance(idx,iNoise).noiseReduction.oSnr.trOff.fbMean);

        dsdMaxSnrFbMean(1,idx,iNoise) = performance(idx,iNoise).signalDistortion.dsd.maxSnr.fbMean;
        dsdWienerFbMean(1,idx,iNoise) = performance(idx,iNoise).signalDistortion.dsd.wiener.fbMean;
        dsdTrOffFbMean(:,idx,iNoise) = squeeze(performance(idx,iNoise).signalDistortion.dsd.trOff.fbMean);
    end
end
%% plots
close all;

figure(1);
plot(10*log10(mean(iSnrFbMean,3)),'k');
hold on;
plot(10*log10(mean(oSnrMaxSnrFbMean,3)),'b');
plot(10*log10(mean(oSnrWienerFbMean,3)),'r');
plot(10*log10(mean(oSnrTrOffFbMean,3).'),'g');
plot(10*log10(mean(oSnrMaxSnrFbMean,3)),'b--');
hold off;

figure(2);
semilogy(10*log10(mean(dsdMaxSnrFbMean,3)),'b');
hold on;
semilogy(10*log10(mean(dsdWienerFbMean,3)),'r');
semilogy(10*log10(mean(dsdTrOffFbMean,3).'),'g');
semilogy(10*log10(mean(dsdMaxSnrFbMean,3)),'b--');
hold off;

%% save
% dateString = datestr(now,30);
% 
% save([mfilename,'_',dateString,'.mat']);
