clc;clear all;close all;

addpath([cd,'\..\data\']);
addpath([cd,'\..\functions\']);

nWin = 50;
nFft = 2^(nextpow2(nWin));

nFiltGrid = 1:6;

filtSetups.minDis.signalRanks = 1;
iSnr = 0;

forgetNoi = 0.99;
forgetSig = 0.95;

signalString = 'twoMaleTwoFemale20Seconds.wav';
noiseStrings = {'babble30Seconds.wav','exhibition30Seconds.wav','street30Seconds.wav','car30Seconds.wav'};
filtStrings = {'maxSnr','minDis','wiener'};

display(['Running script: ',mfilename]);
display(' ');

oSnrMinDisFbMean = NaN(length(nFiltGrid),length(nFiltGrid),length(noiseStrings));
dsdMinDisFbMean = NaN(length(nFiltGrid),length(nFiltGrid),length(noiseStrings));
for iNoise = 1:length(noiseStrings),
    noiseString = char(noiseStrings(iNoise));
    display(['Noise scenario: ',noiseString,' (',num2str(iNoise),' of ',num2str(length(noiseStrings)),')']);
    display('   Enhancing...');
    for idx = 1:length(nFiltGrid),
        display(['   iter #: ',num2str(idx),' of ',num2str(length(nFiltGrid))]);
        nFilt = nFiltGrid(idx);
        filtSetups.minDis.signalRanks = 1:nFilt;

        enhancedData = stftEnhanceSignals(signalString,noiseString,iSnr,nFft,nWin,nFilt,forgetSig,forgetNoi,filtStrings,filtSetups);

        performance(idx,iNoise) = stftMeasurePerformance(enhancedData,filtStrings,1);

    end
    %%
    display('Measuring performance...');
    for idx = 1:length(nFiltGrid),
        iSnrFbMean(1,idx,iNoise) = performance(idx,iNoise).noiseReduction.iSnr.fbMean;
        oSnrMaxSnrFbMean(1,idx,iNoise) = performance(idx,iNoise).noiseReduction.oSnr.maxSnr.fbMean;
        oSnrWienerFbMean(1,idx,iNoise) = performance(idx,iNoise).noiseReduction.oSnr.wiener.fbMean;

        for nn = 1:idx,
            oSnrMinDisFbMean(nn,idx,iNoise) =  performance(idx,iNoise).noiseReduction.oSnr.minDis.fbMean(nn);
            dsdMinDisFbMean(nn,idx,iNoise) =  performance(idx,iNoise).signalDistortion.dsd.minDis.fbMean(nn);
        end

        dsdMaxSnrFbMean(1,idx,iNoise) = performance(idx,iNoise).signalDistortion.dsd.maxSnr.fbMean;
        dsdWienerFbMean(1,idx,iNoise) = performance(idx,iNoise).signalDistortion.dsd.wiener.fbMean;
    end
end

%% plots
close all;

figure(1);
plot(10*log10(mean(iSnrFbMean,3)),'k');
hold on;
plot(10*log10(mean(oSnrMaxSnrFbMean,3)),'b');
plot(10*log10(mean(oSnrWienerFbMean,3)),'r');
plot(10*log10(mean(oSnrMinDisFbMean,3).'),'g');
plot(10*log10(mean(oSnrMaxSnrFbMean,3)),'b--');
hold off;

figure(2);
semilogy((mean(dsdMaxSnrFbMean,3)),'b');
hold on;
semilogy((mean(dsdWienerFbMean,3)),'r');
semilogy((mean(dsdMinDisFbMean,3).'),'g');
semilogy((mean(dsdMaxSnrFbMean,3)),'b--');
hold off;

%% save

% dateString = datestr(now,30);
% 
% save([mfilename,'_',dateString,'.mat']);
