function [mcSignals,setup] = multichannelSignalGenerator(setup)

addpath([cd,'\..\rirGen\']);

setup.nRirLength = 2048;
setup.hpFilterFlag = 1;
setup.reflectionOrder = -1;
setup.micType = 'omnidirectional';

setup.roomDim = [3;4;3];

srcHeight = 1.5;
arrayHeight = 1;

arrayCenter = [setup.roomDim(1:2)/2;1];

arrayToSrcDistInt = [0.75,1];

setup.srcPoint = [0.75;1;1.5];

setup.micPoints = generateUlaCoords(arrayCenter,setup.nSensors,setup.sensorDistance,0,arrayHeight);

[cleanSignal,setup.sampFreq] = audioread('..\data\twoMaleTwoFemale20Seconds.wav');

if setup.reverbTime == 0,
    setup.reverbTime = 0.2;
    reflectionOrder = 0;
else
    reflectionOrder = -1;
end

rirMatrix = rir_generator(setup.speedOfSound,setup.sampFreq,setup.micPoints',setup.srcPoint',setup.roomDim',...
    setup.reverbTime,setup.nRirLength,setup.micType,setup.reflectionOrder,[],[],setup.hpFilterFlag);

for iSens = 1:setup.nSensors,
    tmpCleanSignal(:,iSens) = fftfilt(rirMatrix(iSens,:)',cleanSignal);
end
mcSignals.clean = tmpCleanSignal(setup.nRirLength:end,:);
setup.nSamples = length(mcSignals.clean);

mcSignals.clean = mcSignals.clean - ones(setup.nSamples,1)*mean(mcSignals.clean);

cleanSignalPowerMeas = var(mcSignals.clean);


mcSignals.diffNoise = generateMultichanBabbleNoise(setup.nSamples,setup.nSensors,setup.sensorDistance,...
    setup.speedOfSound,setup.noiseField);
diffNoisePowerMeas = var(mcSignals.diffNoise);
diffNoisePowerTrue = cleanSignalPowerMeas/10^(setup.sdnr/10);
mcSignals.diffNoise = mcSignals.diffNoise*...
    diag(sqrt(diffNoisePowerTrue)./sqrt(diffNoisePowerMeas));

mcSignals.sensNoise = randn(setup.nSamples,setup.nSensors);
sensNoisePowerMeas = var(mcSignals.sensNoise);
sensNoisePowerTrue = cleanSignalPowerMeas/10^(setup.ssnr/10);
mcSignals.sensNoise = mcSignals.sensNoise*...
    diag(sqrt(sensNoisePowerTrue)./sqrt(sensNoisePowerMeas));

mcSignals.noise = mcSignals.diffNoise + mcSignals.sensNoise;
mcSignals.observed = mcSignals.clean + mcSignals.noise;
