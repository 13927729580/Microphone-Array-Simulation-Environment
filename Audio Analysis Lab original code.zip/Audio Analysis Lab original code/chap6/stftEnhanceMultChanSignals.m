function [data,setup] = stftEnhanceMultChanSignals(signals,setup)

if isfield(setup,'noiseOrSignalStat')==0,
    setup.noiseOrSignalStat = 'signal';
end

data.raw.sig = signals.clean;
data.raw.noi = signals.noise;
data.raw.obs = signals.observed;

for iSens = 1:setup.nSensors,
    % apply stft
    [data.raw.sigStft(:,:,iSens),freqGrid,timeGrid,data.raw.sigBlocks(:,:,iSens)] ...
        = stftBatch(signals.clean(:,iSens),setup.nWin,setup.nFft,setup.sampFreq);
    [data.raw.noiStft(:,:,iSens),~,~,data.raw.noiBlocks(:,:,iSens)] ...
        = stftBatch(signals.noise(:,iSens),setup.nWin,setup.nFft,setup.sampFreq);
    [data.raw.obsStft(:,:,iSens),~,~,data.raw.obsBlocks(:,:,iSens)] ...
        = stftBatch(signals.observed(:,iSens),setup.nWin,setup.nFft,setup.sampFreq);
end
[setup.nFreqs,setup.nFrames,~] = size(data.raw.sigStft);


noiCorr = repmat(eye(setup.nFilt*setup.nSensors),1,1,setup.nFreqs);
obsCorr = repmat(eye(setup.nFilt*setup.nSensors),1,1,setup.nFreqs);
sigCorr = repmat(eye(setup.nFilt*setup.nSensors),1,1,setup.nFreqs);
for iFrame = 1:setup.nFrames,
    
    for iFreq=1:setup.nFreqs,
        noiBlock = zeros(setup.nFilt*setup.nSensors,1);
        sigBlock = zeros(setup.nFilt*setup.nSensors,1);
        obsBlock = zeros(setup.nFilt*setup.nSensors,1);
        for iSens = 1:setup.nSensors,
            if iFrame<setup.nFilt,
                noiBlock((1:setup.nFilt)+(iSens-1)*setup.nFilt,1) ...
                    = [data.raw.noiStft(iFreq,iFrame:-1:1,iSens).';zeros(setup.nFilt-iFrame,1)];
                sigBlock((1:setup.nFilt)+(iSens-1)*setup.nFilt,1) ...
                    = [data.raw.sigStft(iFreq,iFrame:-1:1,iSens).';zeros(setup.nFilt-iFrame,1)];
                obsBlock((1:setup.nFilt)+(iSens-1)*setup.nFilt,1) ... 
                    = [data.raw.obsStft(iFreq,iFrame:-1:1,iSens).';zeros(setup.nFilt-iFrame,1)];
            else
                noiBlock((1:setup.nFilt)+(iSens-1)*setup.nFilt,1) ...
                    = data.raw.noiStft(iFreq,iFrame:-1:iFrame-setup.nFilt+1,iSens).';
                sigBlock((1:setup.nFilt)+(iSens-1)*setup.nFilt,1) ...
                    = data.raw.sigStft(iFreq,iFrame:-1:iFrame-setup.nFilt+1,iSens).';
                obsBlock((1:setup.nFilt)+(iSens-1)*setup.nFilt,1) ...
                    = data.raw.obsStft(iFreq,iFrame:-1:iFrame-setup.nFilt+1,iSens).';
            end 
        end

        noiCorr(:,:,iFreq) = (1-setup.forgetNoi)*noiCorr(:,:,iFreq) + (setup.forgetNoi)*(noiBlock*noiBlock');
        obsCorr(:,:,iFreq) = (1-setup.forgetSig)*obsCorr(:,:,iFreq) + (setup.forgetSig)*(obsBlock*obsBlock');
        
        switch setup.noiseOrSignalStat,
            case 'signal',
                sigCorr(:,:,iFreq) = (1-setup.forgetSig)*sigCorr(:,:,iFreq) + (setup.forgetSig)*(sigBlock*sigBlock');
            case 'noise',
                sigCorr(:,:,iFreq) = obsCorr(:,:,iFreq) - noiCorr(:,:,iFreq);
        end
        
        for iFilt = 1:setup.nSensors*setup.nFilt,
            noiCorr(iFilt,iFilt,iFreq) = real(noiCorr(iFilt,iFilt,iFreq));
            obsCorr(iFilt,iFilt,iFreq) = real(obsCorr(iFilt,iFilt,iFreq));
            sigCorr(iFilt,iFilt,iFreq) = real(sigCorr(iFilt,iFilt,iFreq));
        end  
        
        
        regulPar = 1e-10;
        if rank(noiCorr(:,:,iFreq))<setup.nSensors*setup.nFilt,
            noiCorr(:,:,iFreq) = noiCorr(:,:,iFreq)*(1-regulPar)+...
                (regulPar)*trace(noiCorr(:,:,iFreq))/(setup.nFilt*setup.nSensors)*...
                eye(setup.nFilt*setup.nSensors);
        end
        if rank(obsCorr(:,:,iFreq))<setup.nSensors*setup.nFilt,
            obsCorr(:,:,iFreq) = obsCorr(:,:,iFreq)*(1-regulPar)+...
                (regulPar)*trace(obsCorr(:,:,iFreq))/(setup.nFilt*setup.nSensors)*...
                eye(setup.nFilt*setup.nSensors);
        end
        
        % joint diagonalization
        [geigVec(:,:,iFreq),geigVal(:,:,iFreq)] = jeig(sigCorr(:,:,iFreq),...
            noiCorr(:,:,iFreq),1);

        for iFiltStr=1:length(setup.filtStrings),
            switch char(setup.filtStrings(iFiltStr)),
                case 'maxSnr',
                % max snr filt
                hMaxSnr(:,iFreq) = (geigVec(:,1,iFreq)*geigVec(:,1,iFreq)')/geigVal(1,1,iFreq)*sigCorr(:,1,iFreq);
                if norm(hMaxSnr(:,iFreq))==0,
                    hMaxSnr(:,iFreq) = eye(setup.nFilt*setup.nSensors,1);
                end                
                data.maxSnr.sigStft(iFreq,iFrame) = hMaxSnr(:,iFreq)'*sigBlock;
                data.maxSnr.noiStft(iFreq,iFrame) = hMaxSnr(:,iFreq)'*noiBlock;
                data.maxSnr.obsStft(iFreq,iFrame) = hMaxSnr(:,iFreq)'*obsBlock;
                
                case 'wiener',
                % wiener filt
                blbSubW = zeros(setup.nFilt*setup.nSensors);
                if isfield(setup,'wiener')==0,
                    setup.wiener.signalRanks = setup.nFilt;
                end
                iterRanks = 1;
                for iRanks = 1:max(setup.wiener.signalRanks),
                    blbSubW = blbSubW + (geigVec(:,iRanks,iFreq)*geigVec(:,iRanks,iFreq)')...
                        /(1+geigVal(iRanks,iRanks,iFreq));
                    if sum(iRanks==setup.wiener.signalRanks),
                        hWiener(:,iFreq,iterRanks) = blbSubW*sigCorr(:,1,iFreq);
                        if norm(hWiener(:,iFreq,iterRanks))==0,
                            hWiener(:,iFreq,iterRanks) = eye(setup.nFilt*setup.nSensors,1);
                        end
                        iterRanks = iterRanks + 1;  
                    end
                end
                
                for iRanks=1:length(setup.wiener.signalRanks),
                    data.wiener.sigStft(iFreq,iFrame,iRanks) = hWiener(:,iFreq,iRanks)'*sigBlock;
                    data.wiener.noiStft(iFreq,iFrame,iRanks) = hWiener(:,iFreq,iRanks)'*noiBlock;
                    data.wiener.obsStft(iFreq,iFrame,iRanks) = hWiener(:,iFreq,iRanks)'*obsBlock;
                end
                
                case 'minDis',
                % minimum dist filt
                blbSub = zeros(setup.nFilt*setup.nSensors);
                iterRanks = 1;
                for iRanks = 1:max(setup.minDis.signalRanks),
                    blbSub = blbSub + (geigVec(:,iRanks,iFreq)*geigVec(:,iRanks,iFreq)')/geigVal(iRanks,iRanks,iFreq);
                    if sum(iRanks==setup.minDis.signalRanks),
                        hMinDis(:,iFreq,iterRanks) = blbSub*sigCorr(:,1,iFreq);
                        if norm(hMinDis(:,iFreq,iterRanks))==0,
                            hMinDis(:,iFreq,iterRanks) = eye(setup.nFilt*setup.nSensors,1);
                        end
                        iterRanks = iterRanks + 1;
                    end
                end
                for iRanks=1:length(setup.minDis.signalRanks),
                    data.minDis.sigStft(iFreq,iFrame,iRanks) = hMinDis(:,iFreq,iRanks)'*sigBlock;
                    data.minDis.noiStft(iFreq,iFrame,iRanks) = hMinDis(:,iFreq,iRanks)'*noiBlock;
                    data.minDis.obsStft(iFreq,iFrame,iRanks) = hMinDis(:,iFreq,iRanks)'*obsBlock;
                end
                case 'trOff',
                % trade off filt
                blbSub = zeros(setup.nFilt*setup.nSensors);
                iterRanks = 1;
                for iRanks = 1:max(setup.trOff.signalRanks),
                    blbSub = blbSub + (geigVec(:,iRanks,iFreq)*geigVec(:,iRanks,iFreq)')/(setup.trOff.mu+geigVal(iRanks,iRanks,iFreq));
                    if sum(iRanks==setup.trOff.signalRanks),
                        hTrOff(:,iFreq,iterRanks) = blbSub*sigCorr(:,1,iFreq);
                        if norm(hTrOff(:,iFreq,iterRanks))==0,
                            hTrOff(:,iFreq,iterRanks) = eye(setup.nFilt*setup.nSensors,1);
                        end
                        iterRanks = iterRanks + 1;
                    end
                end
                for iRanks=1:length(setup.trOff.signalRanks),
                    data.trOff.sigStft(iFreq,iFrame,iRanks) = hTrOff(:,iFreq,iRanks)'*sigBlock;
                    data.trOff.noiStft(iFreq,iFrame,iRanks) = hTrOff(:,iFreq,iRanks)'*noiBlock;
                    data.trOff.obsStft(iFreq,iFrame,iRanks) = hTrOff(:,iFreq,iRanks)'*obsBlock;
                    data.trOff.sigPow(iFreq,iFrame,iRanks) = real(hTrOff(:,iFreq,iRanks)'*sigCorr(:,:,iFreq)*hTrOff(:,iFreq,iRanks));
                    data.trOff.noiPow(iFreq,iFrame,iRanks) = real(hTrOff(:,iFreq,iRanks)'*noiCorr(:,:,iFreq)*hTrOff(:,iFreq,iRanks));
                    data.trOff.obsPow(iFreq,iFrame,iRanks) = real(hTrOff(:,iFreq,iRanks)'*obsCorr(:,:,iFreq)*hTrOff(:,iFreq,iRanks));
                end
            end
        end

    end
end

for iFiltStr=1:length(setup.filtStrings),
    switch char(setup.filtStrings(iFiltStr)),
        case 'maxSnr',
        data.maxSnr.sig = stftInvBatch(data.maxSnr.sigStft,setup.nWin,setup.nFft);
        data.maxSnr.noi = stftInvBatch(data.maxSnr.noiStft,setup.nWin,setup.nFft);
        data.maxSnr.obs = stftInvBatch(data.maxSnr.obsStft,setup.nWin,setup.nFft);
        case 'wiener',
        for iRanks=1:length(setup.wiener.signalRanks),
            data.wiener.sig(:,iRanks) = stftInvBatch(data.wiener.sigStft(:,:,iRanks),setup.nWin,setup.nFft);
            data.wiener.noi(:,iRanks) = stftInvBatch(data.wiener.noiStft(:,:,iRanks),setup.nWin,setup.nFft);
            data.wiener.obs(:,iRanks) = stftInvBatch(data.wiener.obsStft(:,:,iRanks),setup.nWin,setup.nFft);
        end
        case 'minDis',
        for iRanks=1:length(setup.minDis.signalRanks),
            data.minDis.sig(:,iRanks) = stftInvBatch(data.minDis.sigStft(:,:,iRanks),setup.nWin,setup.nFft);
            data.minDis.noi(:,iRanks) = stftInvBatch(data.minDis.noiStft(:,:,iRanks),setup.nWin,setup.nFft);
            data.minDis.obs(:,iRanks) = stftInvBatch(data.minDis.obsStft(:,:,iRanks),setup.nWin,setup.nFft);
        end
        case 'trOff',
        for iRanks=1:length(setup.trOff.signalRanks),
            data.trOff.sig(:,iRanks) = stftInvBatch(data.trOff.sigStft(:,:,iRanks),setup.nWin,setup.nFft);
            data.trOff.noi(:,iRanks) = stftInvBatch(data.trOff.noiStft(:,:,iRanks),setup.nWin,setup.nFft);
            data.trOff.obs(:,iRanks) = stftInvBatch(data.trOff.obsStft(:,:,iRanks),setup.nWin,setup.nFft);
        end
    end
end

% save setup
setup.stftFreqGrid = freqGrid;
setup.stftTimeGrid = timeGrid;
