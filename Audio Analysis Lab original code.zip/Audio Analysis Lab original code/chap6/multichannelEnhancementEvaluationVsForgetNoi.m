clc;clear all;close all;

addpath([cd,'\..\nonstationaryMultichanNoiseGenerator']);
addpath([cd,'\..\functions\']);

setup.sensorDistance = 0.1;
setup.speedOfSound = 343;
setup.nSensors = 3;
setup.noiseField = 'spherical';
setup.reverbTime = 0.2;

setup.sdnr = 0;
setup.ssnr = 30;

setup.nWin = 80;
setup.nFft = 2^nextpow2(setup.nWin);
setup.nFilt = 4;
setup.forgetNoiGrid = 0.1:0.1:0.9;
setup.forgetSig = 0.95;

setup.filtStrings = {'wiener','minDis','maxSnr'};
setup.minDis.signalRanks = [2,4,6];

display(['Running script: ',mfilename]);
display(' ');

display('Enhancing...');
for idx = 1:length(setup.forgetNoiGrid),
    setup.forgetNoi = setup.forgetNoiGrid(idx);
    [signals,setup] = multichannelSignalGenerator(setup);

    [simulationData,setup] = stftEnhanceMultChanSignals(signals,setup);

    performance(idx,1) = stftMultichannelMeasurePerformance(simulationData,setup,1);
end

display('Measuring performance...');
for idx = 1:length(setup.forgetNoiGrid),
    iSnrFbMean(1,idx) = performance(idx,1).noiseReduction.iSnr.fbMean;
    oSnrMaxSnrFbMean(1,idx) = performance(idx,1).noiseReduction.oSnr.maxSnr.fbMean;
    oSnrWienerFbMean(1,idx) = performance(idx,1).noiseReduction.oSnr.wiener.fbMean;
    oSnrMinDisFbMean(:,idx) = squeeze(performance(idx,1).noiseReduction.oSnr.minDis.fbMean);

    dsdMaxSnrFbMean(1,idx) = performance(idx,1).signalDistortion.dsd.maxSnr.fbMean;
    dsdWienerFbMean(1,idx) = performance(idx,1).signalDistortion.dsd.wiener.fbMean;
    dsdMinDisFbMean(:,idx) = squeeze(performance(idx,1).signalDistortion.dsd.minDis.fbMean);
end

%% save
% dateString = datestr(now,30);
% 
% save([mfilename,'_',dateString,'.mat']);

%% plot
figure(1);
plot(10*log10(mean(iSnrFbMean,3)),'k');
hold on;
plot(10*log10(mean(oSnrMaxSnrFbMean,3)));
plot(10*log10(mean(oSnrWienerFbMean,3)));
plot(10*log10(mean(oSnrMinDisFbMean,3).'),'g');
hold off;

figure(2);
plot(10*log10(mean(dsdMaxSnrFbMean,3)));
hold on;
plot(10*log10(mean(dsdWienerFbMean,3)));
plot(10*log10(mean(dsdMinDisFbMean,3).'),'g');
hold off;
