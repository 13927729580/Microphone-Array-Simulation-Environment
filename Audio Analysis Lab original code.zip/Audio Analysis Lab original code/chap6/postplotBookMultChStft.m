clc;clear all;close all;

set(0,'DefaultAxesFontName','Times');
set(0,'DefaultAxesFontSize',10);

%% load data to plot

% dataVsFftLenStr = 'singleChannelEnhancementEvaluationVsFftLen_20141216T125315.mat';
dataVsFiltLenStr = 'multichannelEnhancementEvaluationVsFiltLen_20150209T133454.mat';
dataVsForgetNoiStr = 'multichannelEnhancementEvaluationVsForgetNoi_20150209T145125.mat';
dataVsForgetSigStr = 'multichannelEnhancementEvaluationVsForgetSig_20150209T150816.mat';
dataVsSnrStr = 'multichannelEnhancementEvaluationVsSnr_20150209T131753.mat';
dataVsTradeOffStr = 'multichannelEnhancementEvaluationVsTradeoff_20150209T112553.mat';
dataVsWinLenStr = 'multichannelEnhancementEvaluationVsWinLen_20150209T134455.mat';
dataVsSensorsStr = 'multichannelEnhancementEvaluationVsSensors_20150209T130639.mat';

% %% plot results versus fft length
% data = load(dataVsFftLenStr);
% 
% h1 = figure(1);
% h1.Position = [316 685 569 653];
% subplot(2,1,1);
% semilogx(data.nFftGrid,10*log10(mean(data.iSnrFbMean,3)),'k--','LineWidth',1);
% hold on;
% semilogx(data.nFftGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'bx-','LineWidth',1);
% semilogx(data.nFftGrid,10*log10(mean(data.oSnrWienerFbMean,3)),'r*-','LineWidth',1);
% semilogx(data.nFftGrid,10*log10(mean(data.oSnrMinDisFbMean,3).'),'gs-','LineWidth',1);
% hold off;
% grid on;
% xlim([min(data.nFftGrid),max(data.nFftGrid)]);
% 
% xlabel('FFT length');
% ylabel('Output SNR [dB]');
% 
% legend('iSNR','Max. SNR','Wiener','Min. dis.');
% 
% for ii = 1:length(data.filtSetups.minDis.signalRanks),
%     hT = text(data.nFftGrid(2),10*log10(mean(data.oSnrMinDisFbMean(ii,2,:),3)),...
%         ['{\it Q} = ',num2str(data.filtSetups.minDis.signalRanks(ii))],...
%         'FontName','Times','VerticalAlignment','bottom');
% end
% 
% subplot(2,1,2);
% loglog(data.nFftGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'bx-','LineWidth',1);
% hold on;
% loglog(data.nFftGrid,10*log10(mean(data.dsdWienerFbMean,3)),'r*-','LineWidth',1);
% loglog(data.nFftGrid,10*log10(mean(data.dsdMinDisFbMean,3).'),'gs-','LineWidth',1);
% hold off;
% grid on;
% xlim([min(data.nFftGrid),max(data.nFftGrid)]);
% 
% xlabel('FFT length');
% ylabel('Signal reduction factor [dB]');
% 
% legend('Max. SNR','Wiener','Min. dis.');
% 
% for ii = 1:length(data.filtSetups.minDis.signalRanks),
%     hT = text(data.nFftGrid(2),10*log10(mean(data.dsdMinDisFbMean(ii,2,:),3)),...
%         ['{\it Q} = ',num2str(data.filtSetups.minDis.signalRanks(ii))],...
%         'FontName','Times','VerticalAlignment','bottom');
% end
% 
%% plot results versus filter length
data = load(dataVsFiltLenStr);

% keyboard;

tmp = mean(data.oSnrMinDisFbMean,3).';

h2 = figure(2);
h2.Position = [316 685 569 653];
h2s1 = subplot(2,1,1);
% plot(data.setup.nFiltGrid,10*log10(mean(data.iSnrFbMean,3)),'k--','LineWidth',1);
% hold on;
plot(data.setup.nFiltGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.nFiltGrid,10*log10(mean(data.oSnrWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.setup.nFiltGrid,10*log10(tmp(:,[2,4])),'gs-','LineWidth',1);
plot(data.setup.nFiltGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'b-','LineWidth',1);
plot(data.setup.nFiltGrid,10*log10(tmp(:,[2,4])),'g--','LineWidth',1);
hold off;
grid on;

h2s1.XTick = data.setup.nFiltGrid;

xlabel('Filter length');
ylabel('Output SNR [dB]');

legend('Max. SNR','Wiener','Min. dis.','Location','SouthEast');

for ii = 1:length(data.setup.nFiltGrid),
    tmp = 10*log10(mean(data.oSnrMinDisFbMean,3));
    if ii==2||ii==4,
    hT = text(data.setup.nFiltGrid(max([2,ii])),tmp(ii,max([2,ii])),...
        ['{\it Q} = ',num2str(data.setup.nFiltGrid(ii))],...
        'FontName','Times','VerticalAlignment','top',...
        'HorizontalAlignment','right');
    end
end

tmp = (mean(data.dsdMinDisFbMean,3).');
tmp(tmp==0) = NaN;

h2s2 = subplot(2,1,2);
plot(data.setup.nFiltGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.nFiltGrid,10*log10(mean(data.dsdWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.setup.nFiltGrid,10*log10(tmp(:,[2,4])),'gs-','LineWidth',1);
plot(data.setup.nFiltGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'b-','LineWidth',1);
plot(data.setup.nFiltGrid,10*log10(tmp(:,[2,4])),'g--','LineWidth',1);
hold off;
grid on;

h2s2.XTick = data.setup.nFiltGrid;

xlabel('Filter length');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','Min. dis.');

% keyboard
for ii = 1:length(data.setup.nFiltGrid),
    tmp = (mean(data.dsdMinDisFbMean,3));
    if ii==2||ii==4,
    hT = text(data.setup.nFiltGrid(max([2,ii])),10*log10(tmp(ii,max([2,ii]))),...
        ['{\it Q} = ',num2str(data.setup.nFiltGrid(ii))],...
        'FontName','Times','VerticalAlignment','bottom',...
        'HorizontalAlignment','right');
    end
end

% subplot(3,1,3);
% plot(10*log10(mean(data.dsdMaxSnrFbMean,3)),'b');
% hold on;
% % plot(10*log10(mean(data.dsdWienerFbMean,3)),'r');
% plot(10*log10(mean(data.dsdMinDisFbMean,3).'),'g--');
% hold off;

%%
data = load(dataVsForgetNoiStr);

h3 = figure(3);
h3.Position = [316 685 569 653];
subplot(2,1,1);
% plot(data.setup.forgetNoiGrid,10*log10(mean(data.iSnrFbMean,3)),'k','LineWidth',1);
% hold on;
plot(data.setup.forgetNoiGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.forgetNoiGrid,10*log10(mean(data.oSnrWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.setup.forgetNoiGrid,10*log10(mean(data.oSnrMinDisFbMean(1:2,:),3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Noise forgetting factor');
ylabel('Output SNR [dB]');

legend('Max. SNR','Wiener','Min. dis.','Location','NorthWest');

for ii = 1:length(data.setup.minDis.signalRanks(1:2)),
    hT = text(data.setup.forgetNoiGrid(2),10*log10(mean(data.oSnrMinDisFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.setup.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment','bottom');
end

subplot(2,1,2);
plot(data.setup.forgetNoiGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.forgetNoiGrid,10*log10(mean(data.dsdWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.setup.forgetNoiGrid,10*log10(mean(data.dsdMinDisFbMean(1:2,:),3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Noise forgetting factor');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','Min. dis.');

for ii = 1:length(data.setup.minDis.signalRanks(1:2)),
    if ii==3,
        alignString = 'top';
    else 
        alignString = 'bottom';
    end
    
    if ii ==1,
        hT = text(data.setup.forgetNoiGrid(1),10*log10(mean(data.dsdMinDisFbMean(ii,1,:),3)),...
        ['{\it Q} = ',num2str(data.setup.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment',alignString);
    else
    hT = text(data.setup.forgetNoiGrid(2),10*log10(mean(data.dsdMinDisFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.setup.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment',alignString);
    end
end


%%
data = load(dataVsForgetSigStr);

% keyboard

h4 = figure(4);
h4.Position = [316 685 569 653];
subplot(2,1,1);
% plot(data.setup.forgetSigGrid,10*log10(mean(data.iSnrFbMean,3)),'k--','LineWidth',1);
% hold on;
plot(data.setup.forgetSigGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.forgetSigGrid,10*log10(mean(data.oSnrWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.setup.forgetSigGrid,10*log10(mean(data.oSnrMinDisFbMean(1:2,:),3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Signal forgetting factor');
ylabel('Output SNR [dB]');

legend('Max. SNR','Wiener','Min. dis.');

for ii = 1:length(data.setup.minDis.signalRanks(1:2)),
    hT = text(data.setup.forgetSigGrid(2),10*log10(mean(data.oSnrMinDisFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.setup.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment','bottom');
end

subplot(2,1,2);
plot(data.setup.forgetSigGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.forgetSigGrid,10*log10(mean(data.dsdWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.setup.forgetSigGrid,10*log10(mean(data.dsdMinDisFbMean(1:2,:),3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Signal forgetting factor');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','Min. dis.');

for ii = 1:length(data.setup.minDis.signalRanks(1:2)),
    if ii == 3,
        hT = text(data.setup.forgetSigGrid(end),10*log10(mean(data.dsdMinDisFbMean(ii,end,:),3)),...
        ['{\it Q} = ',num2str(data.setup.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment','bottom');
    else 
        hT = text(data.setup.forgetSigGrid(2),10*log10(mean(data.dsdMinDisFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.setup.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment','bottom');
    end
end

%%
data = load(dataVsSnrStr);

% keyboard

h5 = figure(5);
h5.Position = [316 685 569 653];
subplot(2,1,1);
plot(data.setup.sdnrGrid,10*log10(mean(data.iSnrFbMean,3)),'k--','LineWidth',1);
hold on;
plot(data.setup.sdnrGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'bx-','LineWidth',1);
% hold on;
plot(data.setup.sdnrGrid,10*log10(mean(data.oSnrWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.setup.sdnrGrid,10*log10(mean(data.oSnrMinDisFbMean(1:2,:),3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Signal-to-diffuse-noise ratio [dB]');
ylabel('Output SNR [dB]');

legend('iSNR','Max. SNR','Wiener','Min. dis.','Location','West');

for ii = 1:length(data.setup.minDis.signalRanks(1:2)),
    if ii==1,
        alignString = 'bottom';
    else 
        alignString = 'top';
    end
    hT = text(data.setup.sdnrGrid(2),10*log10(mean(data.oSnrMinDisFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.setup.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment',alignString);
end

subplot(2,1,2);
plot(data.setup.sdnrGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.sdnrGrid,10*log10(mean(data.dsdWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.setup.sdnrGrid,10*log10(mean(data.dsdMinDisFbMean(1:2,:),3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Signal-to-diffuse-noise ratio [dB]');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','Min. dis.','Location','West');

for ii = 1:length(data.setup.minDis.signalRanks(1:2)),
    if ii==3,
        alignString = 'top';
    else
        alignString = 'bottom'; 
    end
    hT = text(data.setup.sdnrGrid(2),10*log10(mean(data.dsdMinDisFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.setup.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment',alignString);
end

%%
data = load(dataVsTradeOffStr);

h6 = figure(6);
h6.Position = [316 685 569 653];
subplot(2,1,1);
% plot(data.setup.trOff.muGrid,10*log10(mean(data.iSnrFbMean,3)),'k--','LineWidth',1);
% hold on;
plot(data.setup.trOff.muGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.trOff.muGrid,10*log10(mean(data.oSnrWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.setup.trOff.muGrid,10*log10(mean(data.oSnrTrOffFbMean(1:2,:,:),3).'),'co-','LineWidth',1);
plot(data.setup.trOff.muGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'b-','LineWidth',1);
plot(data.setup.trOff.muGrid,10*log10(mean(data.oSnrTrOffFbMean(1,:,:),3).'),'c--','LineWidth',1);
hold off;
grid on;
xlim([min(data.setup.trOff.muGrid),max(data.setup.trOff.muGrid)]);

xlabel('Tradeoff parameter');
ylabel('Output SNR [dB]');

legend('Max. SNR','Wiener','Tradeoff','Location','NorthEast');

for ii = 1:length(data.setup.trOff.signalRanks(1:2)),
    hT = text(data.setup.trOff.muGrid(2),10*log10(mean(data.oSnrTrOffFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.setup.trOff.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment','bottom');
end

subplot(2,1,2);
plot(data.setup.trOff.muGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.trOff.muGrid,10*log10(mean(data.dsdWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.setup.trOff.muGrid,10*log10(mean(data.dsdTrOffFbMean(1:2,:,:),3).'),'co-','LineWidth',1);
plot(data.setup.trOff.muGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'b-','LineWidth',1);
plot(data.setup.trOff.muGrid,10*log10(mean(data.dsdTrOffFbMean(1,:,:),3).'),'c--','LineWidth',1);
hold off;
grid on;
xlim([min(data.setup.trOff.muGrid),max(data.setup.trOff.muGrid)]);
% ylim([1e-4,1e0]);

xlabel('Tradeoff parameter');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','Tradeoff','Location','East');

for ii = 1:length(data.setup.trOff.signalRanks(1:2)),
    if ii==3,
        alignString = 'top';
    else
        alignString = 'bottom'; 
    end
    hT = text(data.setup.trOff.muGrid(2),10*log10(mean(data.dsdTrOffFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.setup.trOff.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment',alignString);
end

%%
data = load(dataVsWinLenStr);

h7 = figure(7);
h7.Position = [316 685 569 653];
subplot(2,1,1);
% plot(data.setup.nWinGrid,10*log10(mean(data.iSnrFbMean,3)),'k--','LineWidth',1);
% hold on;
plot(data.setup.nWinGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.nWinGrid,10*log10(mean(data.oSnrWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.setup.nWinGrid,10*log10(mean(data.oSnrMinDisFbMean(1:2,:),3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Window length');
ylabel('Output SNR [dB]');

legend('Max. SNR','Wiener','Min. dis.');

for ii = 1:length(data.setup.minDis.signalRanks(1:2)),
    hT = text(data.setup.nWinGrid(2),10*log10(mean(data.oSnrMinDisFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.setup.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment','bottom');
end

subplot(2,1,2);
plot(data.setup.nWinGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.nWinGrid,10*log10(mean(data.dsdWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.setup.nWinGrid,10*log10(mean(data.dsdMinDisFbMean(1:2,:),3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Window length');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','Min. dis.');

for ii = 1:length(data.setup.minDis.signalRanks(1:2)),
    if ii==3,
        alignString = 'top';
    else
        alignString = 'bottom'; 
    end
    hT = text(data.setup.nWinGrid(2),10*log10(mean(data.dsdMinDisFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.setup.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment',alignString);
    ylim([-2e-3,18e-3]);
end

%%
data = load(dataVsSensorsStr);

% keyboard

h8 = figure(8);
h8.Position = [316 685 569 653];
h8s1 = subplot(2,1,1);
% plot(data.setup.nSensorsGrid,10*log10(mean(data.iSnrFbMean,3)),'k--','LineWidth',1);
% hold on;
plot(data.setup.nSensorsGrid,10*log10(mean(data.oSnrMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.nSensorsGrid,10*log10(mean(data.oSnrWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.setup.nSensorsGrid,10*log10(mean(data.oSnrMinDisFbMean(1:2,:),3).'),'gs-','LineWidth',1);
hold off;
grid on;

h8s1.XTick = data.setup.nSensorsGrid;

xlabel('Number of sensors');
ylabel('Output SNR [dB]');

legend('Max. SNR','Wiener','Min. dis.','Location','SouthEast');

for ii = 1:length(data.setup.minDis.signalRanks(1:2)),
    if ii==1,
        alignString = 'bottom';
    else 
        alignString = 'top';
    end
    hT = text(data.setup.nSensorsGrid(2),10*log10(mean(data.oSnrMinDisFbMean(ii,2,:),3)),...
        ['{\it Q} = ',num2str(data.setup.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment',alignString);
end

h8s2 = subplot(2,1,2);
plot(data.setup.nSensorsGrid,10*log10(mean(data.dsdMaxSnrFbMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.nSensorsGrid,10*log10(mean(data.dsdWienerFbMean,3)),'r*-','LineWidth',1);
plot(data.setup.nSensorsGrid,10*log10(mean(data.dsdMinDisFbMean(1:2,:),3).'),'gs-','LineWidth',1);
hold off;
grid on;

h8s2.XTick = data.setup.nSensorsGrid;

xlabel('Number of sensors');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','Min. dis.','Location','NorthEast');

for ii = 1:length(data.setup.minDis.signalRanks(1:2)),
    if ii==3,
        alignString = 'top';
    else 
        alignString = 'bottom';
    end
    hT = text(data.setup.nSensorsGrid(1),(mean(data.dsdMinDisFbMean(ii,1,:),3)),...
        ['{\it Q} = ',num2str(data.setup.minDis.signalRanks(ii))],...
        'FontName','Times','VerticalAlignment',alignString);
end

%% save plots
% 
% export_fig('plotSingChanStftVsFftLen.eps','-painters','-nocrop','-transparent',1);
export_fig('plotMultChanStftVsFiltLen.eps','-painters','-nocrop','-transparent',2);
export_fig('plotMultChanStftVsForgetNoi.eps','-painters','-nocrop','-transparent',3);
export_fig('plotMultChanStftVsForgetSig.eps','-painters','-nocrop','-transparent',4);
export_fig('plotMultChanStftVsSnr.eps','-painters','-nocrop','-transparent',5);
export_fig('plotMultChanStftVsTrOff.eps','-painters','-nocrop','-transparent',6);
export_fig('plotMultChanStftVsWinLen.eps','-painters','-nocrop','-transparent',7);
export_fig('plotMultChanStftVsSensors.eps','-painters','-nocrop','-transparent',8);