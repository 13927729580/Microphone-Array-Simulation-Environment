clc;clear all;close all;

addpath([cd,'\..\nonstationaryMultichanNoiseGenerator']);
addpath([cd,'\..\functions\']);

setup.sensorDistance = 0.1;
setup.speedOfSound = 343;
setup.nSensors = 3;
setup.noiseField = 'spherical';
setup.reverbTime = 0.2;

setup.sdnr = 0;
setup.ssnr = 30;

setup.nWin = 60;
setup.forgetNoi = 0.8;
setup.forgetSig = 0.8;

setup.filtStrings = {'wiener','mvdr','maxSnr','trOff'};

setup.trOff.signalRanks = 1:1:10;
setup.trOff.mu = 1;

display(['Running script: ',mfilename]);
display(' ');

display('Enhancing...');
[signals,setup] = multichannelSignalGenerator(setup);

[simulationData,setup] = vsTimeDomEnhanceMultChanSignals(signals,setup);

performance(1,1) = vsTimeDomMultichannelMeasurePerformance(simulationData,setup,1);

%%
display('Measuring performance...');
iSnrMean(1,1) = performance(1,1).noiseReduction.iSnr.mean;
oSnrMaxSnrMean(1,1) = performance(1,1).noiseReduction.oSnr.maxSnr.mean;
oSnrWienerMean(1,1) = performance(1,1).noiseReduction.oSnr.wiener.mean;
oSnrMvdrMean(1,1) = performance(1,1).noiseReduction.oSnr.mvdr.mean;

dsdMaxSnrMean(1,1) = performance(1,1).signalDistortion.dsd.maxSnr.mean;
dsdWienerMean(1,1) = performance(1,1).signalDistortion.dsd.wiener.mean;
dsdMvdrMean(1,1) = performance(1,1).signalDistortion.dsd.mvdr.mean;
for idx = 1:length(setup.trOff.signalRanks),
    oSnrTrOffMean(1,idx) = performance(1,1).noiseReduction.oSnr.trOff.mean(:,:,idx);
    
    dsdTrOffMean(1,idx) = performance(1,1).signalDistortion.dsd.trOff.mean(:,:,idx);
end

%% save
% dateString = datestr(now,30);
% 
% save([mfilename,'_',dateString,'.mat']);

%% plot
close all;
figure(1);
plot(10*log10(mean(iSnrMean,3))*ones(1,length(setup.trOff.signalRanks)),'k');
hold on;
plot(10*log10(mean(oSnrMaxSnrMean,3))*ones(1,length(setup.trOff.signalRanks)));
plot(10*log10(mean(oSnrWienerMean,3))*ones(1,length(setup.trOff.signalRanks)));
plot(10*log10(mean(oSnrMvdrMean,3).'*ones(1,length(setup.trOff.signalRanks))),'g');
plot(10*log10(mean(oSnrTrOffMean,3).'),'m');
hold off;

figure(2);
plot(10*log10(mean(dsdMaxSnrMean,3))*ones(1,length(setup.trOff.signalRanks)));
hold on;
plot(10*log10(mean(dsdWienerMean,3))*ones(1,length(setup.trOff.signalRanks)));
plot(10*log10(mean(dsdMvdrMean,3).')*ones(1,length(setup.trOff.signalRanks)),'g');
plot(10*log10(mean(dsdTrOffMean,3).'),'m');
hold off;
