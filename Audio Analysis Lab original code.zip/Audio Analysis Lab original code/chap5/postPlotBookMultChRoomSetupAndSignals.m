clc;clear all; close all;

addpath([cd,'\..\functions\']);
addpath([cd,'\..\rirGen\']);
addpath([cd,'\..\nonstationaryMultichanNoiseGenerator\']);

set(0,'DefaultAxesFontName','Times');
set(0,'DefaultAxesFontSize',10);

setup.nSensors = 3;
setup.sensorDistance = 0.1;

setup.roomDim = [3;4;3];

srcHeight = 1.5;
arrayHeight = 1;

arrayCenter = [setup.roomDim(1:2)/2;1];

arrayToSrcDistInt = [0.75,1];

setup.srcPoint = [0.75;1;1.5];

setup.micPoints = generateUlaCoords(arrayCenter,setup.nSensors,setup.sensorDistance,0,arrayHeight);

hFig1 = figure(1);
hFig1.Position = [1000 901 602 437];
plot3(setup.srcPoint(1),setup.srcPoint(2),setup.srcPoint(3),'bs','MarkerSize',10,'LineWidth',1);
hold on;
plot3(setup.micPoints(1,:),setup.micPoints(2,:),setup.micPoints(3,:),'ro','MarkerSize',8,'LineWidth',1);

plot3([0,setup.srcPoint(1)],...
    [setup.srcPoint(2),setup.srcPoint(2)],...
    [setup.srcPoint(3),setup.srcPoint(3)],'k--');
plot3([setup.srcPoint(1),setup.srcPoint(1)],...
    [setup.srcPoint(2),setup.roomDim(2)],...
    [setup.srcPoint(3),setup.srcPoint(3)],'k--');
plot3([setup.srcPoint(1),setup.srcPoint(1)],...
    [setup.srcPoint(2),setup.srcPoint(2)],...
    [0,setup.srcPoint(3)],'k--');

plot3([0,setup.micPoints(1,2)],...
    [setup.micPoints(2,2),setup.micPoints(2,2)],...
    [setup.micPoints(3,2),setup.micPoints(3,2)],'k--');
plot3([setup.micPoints(1,2),setup.micPoints(1,2)],...
    [setup.micPoints(2,2),setup.roomDim(2)],...
    [setup.micPoints(3,2),setup.micPoints(3,2)],'k--');
plot3([setup.micPoints(1,2),setup.micPoints(1,2)],...
    [setup.micPoints(2,2),setup.micPoints(2,2)],...
    [0,setup.micPoints(3,2)],'k--');
hold off;

xlim([0,setup.roomDim(1)]);
ylim([0,setup.roomDim(2)]);
zlim([0,setup.roomDim(3)]);
grid on;

box on;

view([50,15]);

xlabel('x [m]');
ylabel('y [m]');
zlabel('z [m]');

hLeg = legend('Source','Mic.');
hLeg.Position = [0.7085 0.7045 0.1595 0.0752];

%%
[cleanSignal,setup.sampFreq] = audioread('..\data\twoMaleTwoFemale20Seconds.wav');

setup.reverbTime = 0.2;
if setup.reverbTime == 0,
    setup.reverbTime = 0.2;
    setup.reflectionOrder = 0;
else
    setup.reflectionOrder = -1;
end
setup.hpFilterFlag = 1;
setup.micType = 'omnidirectional';
setup.nRirLength = 2048;
setup.speedOfSound = 343;
setup.noiseField = 'spherical';
setup.sdnr = 0;

rirMatrix = rir_generator(setup.speedOfSound,setup.sampFreq,setup.micPoints',setup.srcPoint',setup.roomDim',...
    setup.reverbTime,setup.nRirLength,setup.micType,setup.reflectionOrder,[],[],setup.hpFilterFlag);

for iSens = 1:setup.nSensors,
    tmpCleanSignal(:,iSens) = fftfilt(rirMatrix(iSens,:)',cleanSignal);
end
mcSignals.clean = tmpCleanSignal(setup.nRirLength:end,:);
setup.nSamples = length(mcSignals.clean);

mcSignals.clean = mcSignals.clean - ones(setup.nSamples,1)*mean(mcSignals.clean);

mcSignals.diffNoise = generateMultichanBabbleNoise(setup.nSamples,setup.nSensors,setup.sensorDistance,...
    setup.speedOfSound,setup.noiseField);


cleanSignalPowerMeas = var(mcSignals.clean);
diffNoisePowerMeas = var(mcSignals.diffNoise);
diffNoisePowerTrue = cleanSignalPowerMeas/10^(setup.sdnr/10);
mcSignals.diffNoise = mcSignals.diffNoise*...
    diag(sqrt(diffNoisePowerTrue)./sqrt(diffNoisePowerMeas));

%%
timeLimit = 5;
timeNdxLimit = round(setup.sampFreq*timeLimit);

nWin = 512;
nOverlap = 300;
nFft = 2048;
[speechSpec,freqSpec,timeSpec,speechPsd] = spectrogram(mcSignals.clean(1:timeNdxLimit,1),...
    nWin,nOverlap,nFft,setup.sampFreq);

timeT = (1:timeNdxLimit)/setup.sampFreq;

h2 = figure(2);
h2.Position = [834 456 574 582];
subplot(2,1,1);
plot(timeT,mcSignals.clean(1:timeNdxLimit,1));
grid on;
xlim([0.1,4.9]);

xlabel('Time [s]');
ylabel('Amplitude');

subplot(2,1,2);
handleIm = imagesc(timeSpec,freqSpec,20*log10(abs(speechSpec)));
view([0,-90]);
xlim([0.1,4.9]);

xlabel('Time [s]');
ylabel('Frequency [Hz]');

hCb2 = colorbar;
hCb2.Position = [0.8574 0.1100 0.0465 0.3412];

%%
[diffNoiseSpec,freqSpec,timeSpec,diffNoisePsd] = spectrogram(mcSignals.diffNoise(1:timeNdxLimit,1),...
    nWin,nOverlap,nFft,setup.sampFreq);

h3 = figure(3);
h3.Position = [834 456 574 582];
subplot(2,1,1);
plot(timeT,mcSignals.diffNoise(1:timeNdxLimit,1));
grid on;
xlim([0.1,4.9]);

xlabel('Time [s]');
ylabel('Amplitude');

subplot(2,1,2);
handleIm = imagesc(timeSpec,freqSpec,20*log10(abs(diffNoiseSpec)));
view([0,-90]);
xlim([0.1,4.9]);

xlabel('Time [s]');
ylabel('Frequency [Hz]');

hCb3 = colorbar;
hCb3.Position = [0.8574 0.1100 0.0465 0.3412];
