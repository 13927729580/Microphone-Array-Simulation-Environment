clc;clear all;close all;

set(0,'DefaultAxesFontName','Times');
set(0,'DefaultAxesFontSize',10);

%% load data to plot

dataVsFiltLenStr = 'multichannelEnhancementVSTimeDomainEvalVsWinLen_20150303T110626.mat';
dataVsForgetNoiStr = 'multichannelEnhancementVSTimeDomainEvalVsForgetNoi_20150303T164501.mat';
dataVsForgetSigStr = 'multichannelEnhancementVSTimeDomainEvalVsForgetSig_20150303T164534.mat';
dataVsSnrStr = 'multichannelEnhancementVSTimeDomainEvalVsSnr_20150303T104622.mat';
dataVsTradeOffMuStr = 'multichannelEnhancementVSTimeDomainEvalVsTradeoffMu_20150303T130740.mat';
dataVsTradeOffRankStr = 'multichannelEnhancementVSTimeDomainEvalVsTradeoffRank_20150303T125441.mat';
dataVsSensorsStr = 'multichannelEnhancementVSTimeDomainEvalVsNSensors_20150303T104446.mat';

%% plot results versus filter length
data = load(dataVsFiltLenStr);

h2 = figure(2);
h2.Position = [316 685 569 653];
subplot(2,1,1);
plot(data.setup.nWinGrid,10*log10(mean(data.oSnrMaxSnrMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.nWinGrid,10*log10(mean(data.oSnrWienerMean,3)),'r*-','LineWidth',1);
plot(data.setup.nWinGrid,10*log10(mean(data.oSnrMvdrMean,3)),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Filter length');
ylabel('Output SNR [dB]');

legend('Max. SNR','Wiener','MVDR','Location','SouthEast');

subplot(2,1,2);
plot(data.setup.nWinGrid,10*log10(mean(data.dsdMaxSnrMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.nWinGrid,10*log10(mean(data.dsdWienerMean,3)),'r*-','LineWidth',1);
plot(data.setup.nWinGrid,10*log10(mean(data.dsdMvdrMean,3)),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Filter length');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','MVDR');

%% plot results versus noise forgetting factor
data = load(dataVsForgetNoiStr);

h3 = figure(3);
h3.Position = [316 685 569 653];
subplot(2,1,1);
plot(data.setup.forgetNoiGrid,10*log10(mean(data.oSnrMaxSnrMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.forgetNoiGrid,10*log10(mean(data.oSnrWienerMean,3)),'r*-','LineWidth',1);
plot(data.setup.forgetNoiGrid,10*log10(mean(data.oSnrMvdrMean,3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlim([data.setup.forgetNoiGrid(1),data.setup.forgetNoiGrid(end)]);

xlabel('Noise forgetting factor');
ylabel('Output SNR [dB]');

legend('Max. SNR','Wiener','MVDR','Location','NorthWest');

subplot(2,1,2);
plot(data.setup.forgetNoiGrid,10*log10(mean(data.dsdMaxSnrMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.forgetNoiGrid,10*log10(mean(data.dsdWienerMean,3)),'r*-','LineWidth',1);
plot(data.setup.forgetNoiGrid,10*log10(mean(data.dsdMvdrMean,3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlim([data.setup.forgetNoiGrid(1),data.setup.forgetNoiGrid(end)]);

xlabel('Noise forgetting factor');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','MVDR','Location','West');

%% plot results versus signal forgetting factor
data = load(dataVsForgetSigStr);

h4 = figure(4);
h4.Position = [316 685 569 653];
subplot(2,1,1);
plot(data.setup.forgetSigGrid,10*log10(mean(data.oSnrMaxSnrMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.forgetSigGrid,10*log10(mean(data.oSnrWienerMean,3)),'r*-','LineWidth',1);
plot(data.setup.forgetSigGrid,10*log10(mean(data.oSnrMvdrMean,3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlim([data.setup.forgetSigGrid(1),data.setup.forgetSigGrid(end)]);

xlabel('Signal forgetting factor');
ylabel('Output SNR [dB]');

legend('Max. SNR','Wiener','MVDR','Location','SouthEast');

subplot(2,1,2);
plot(data.setup.forgetSigGrid,10*log10(mean(data.dsdMaxSnrMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.forgetSigGrid,10*log10(mean(data.dsdWienerMean,3)),'r*-','LineWidth',1);
plot(data.setup.forgetSigGrid,10*log10(mean(data.dsdMvdrMean,3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlim([data.setup.forgetSigGrid(1),data.setup.forgetSigGrid(end)]);

xlabel('Signal forgetting factor');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','MVDR');

%% plot results versus signal to diffuse noise ratio
data = load(dataVsSnrStr);

h5 = figure(5);
h5.Position = [316 685 569 653];
subplot(2,1,1);
plot(data.setup.sdnrGrid,10*log10(mean(data.iSnrMean,3)),'k--','LineWidth',1);
hold on;
plot(data.setup.sdnrGrid,10*log10(mean(data.oSnrMaxSnrMean,3)),'bx-','LineWidth',1);
% hold on;
plot(data.setup.sdnrGrid,10*log10(mean(data.oSnrWienerMean,3)),'r*-','LineWidth',1);
plot(data.setup.sdnrGrid,10*log10(mean(data.oSnrMvdrMean,3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Signal-to-diffuse-noise ratio [dB]');
ylabel('Output SNR [dB]');

legend('iSNR','Max. SNR','Wiener','MVDR','Location','East');

subplot(2,1,2);
plot(data.setup.sdnrGrid,10*log10(mean(data.dsdMaxSnrMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.sdnrGrid,10*log10(mean(data.dsdWienerMean,3)),'r*-','LineWidth',1);
plot(data.setup.sdnrGrid,10*log10(mean(data.dsdMvdrMean,3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Signal-to-diffuse-noise ratio [dB]');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','MVDR','Location','West');

%% plot results versus tradeoff parameter (\mu)
data = load(dataVsTradeOffMuStr);

h6 = figure(6);
h6.Position = [316 685 569 653];
subplot(2,1,1);
plot(data.setup.trOff.muGrid,10*log10(mean(data.oSnrMaxSnrMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.trOff.muGrid,10*log10(mean(data.oSnrWienerMean,3)),'r*-','LineWidth',1);
plot(data.setup.trOff.muGrid,10*log10(mean(data.oSnrMvdrMean,3)),'gs-','LineWidth',1);
plot(data.setup.trOff.muGrid,10*log10(mean(data.oSnrTrOffMean,3).'),'co-','LineWidth',1);
hold off;
grid on;
xlim([min(data.setup.trOff.muGrid),max(data.setup.trOff.muGrid)]);

xlabel('Tradeoff parameter');
ylabel('Output SNR [dB]');

legend('Max. SNR','Wiener','MVDR','Tradeoff','Location','East');

subplot(2,1,2);
plot(data.setup.trOff.muGrid,10*log10(mean(data.dsdMaxSnrMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.trOff.muGrid,10*log10(mean(data.dsdWienerMean,3)),'r*-','LineWidth',1);
plot(data.setup.trOff.muGrid,10*log10(mean(data.dsdMvdrMean,3)),'gs-','LineWidth',1);
plot(data.setup.trOff.muGrid,10*log10(mean(data.dsdTrOffMean,3)),'co-','LineWidth',1);
hold off;
grid on;
xlim([min(data.setup.trOff.muGrid),max(data.setup.trOff.muGrid)]);

xlabel('Tradeoff parameter');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','MVDR','Tradeoff','Location','East');

%% plot results versus tradeoff parameter (rank)
data = load(dataVsTradeOffRankStr);

h7 = figure(7);
h7.Position = [316 685 569 653];
subplot(2,1,1);

plot(data.setup.trOff.signalRanks,10*log10(mean(data.oSnrMaxSnrMean,3))...
    *ones(length(data.setup.trOff.signalRanks),1),'bx-','LineWidth',1);
hold on;
plot(data.setup.trOff.signalRanks,10*log10(mean(data.oSnrWienerMean,3))...
    *ones(length(data.setup.trOff.signalRanks),1),'r*-','LineWidth',1);
plot(data.setup.trOff.signalRanks,10*log10(mean(data.oSnrMvdrMean,3))...
    *ones(length(data.setup.trOff.signalRanks),1),'gs-','LineWidth',1);
plot(data.setup.trOff.signalRanks,10*log10(mean(data.oSnrTrOffMean,3).'),'co-','LineWidth',1);
hold off;
grid on;

xlabel('Tradeoff rank');
ylabel('Output SNR [dB]');

legend('Max. SNR','Wiener','MVDR','Tradeoff','Location','East');

subplot(2,1,2);
plot(data.setup.trOff.signalRanks,10*log10(mean(data.dsdMaxSnrMean,3))...
    *ones(length(data.setup.trOff.signalRanks),1),'bx-','LineWidth',1);
hold on;
plot(data.setup.trOff.signalRanks,10*log10(mean(data.dsdWienerMean,3))...
    *ones(length(data.setup.trOff.signalRanks),1),'r*-','LineWidth',1);
plot(data.setup.trOff.signalRanks,10*log10(mean(data.dsdMvdrMean,3))...
    *ones(length(data.setup.trOff.signalRanks),1),'gs-','LineWidth',1);
plot(data.setup.trOff.signalRanks,10*log10(mean(data.dsdTrOffMean,3)),'co-','LineWidth',1);
hold off;
grid on;

xlabel('Tradeoff rank');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','MVDR','Tradeoff','Location','East');

%% plot results versus number of sensors
data = load(dataVsSensorsStr);

h8 = figure(8);
h8.Position = [316 685 569 653];
h8s1 = subplot(2,1,1);

plot(data.setup.nSensorsGrid,10*log10(mean(data.oSnrMaxSnrMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.nSensorsGrid,10*log10(mean(data.oSnrWienerMean,3)),'r*-','LineWidth',1);
plot(data.setup.nSensorsGrid,10*log10(mean(data.oSnrMvdrMean,3).'),'gs-','LineWidth',1);
hold off;
grid on;

xlabel('Number of sensors');
ylabel('Output SNR [dB]');

h8s1.XTick = data.setup.nSensorsGrid;

legend('Max. SNR','Wiener','MVDR','Location','SouthEast');

h8s2 = subplot(2,1,2);
plot(data.setup.nSensorsGrid,10*log10(mean(data.dsdMaxSnrMean,3)),'bx-','LineWidth',1);
hold on;
plot(data.setup.nSensorsGrid,10*log10(mean(data.dsdWienerMean,3)),'r*-','LineWidth',1);
plot(data.setup.nSensorsGrid,10*log10(mean(data.dsdMvdrMean,3).'),'gs-','LineWidth',1);
hold off;
grid on;

h8s2.XTick = data.setup.nSensorsGrid;

xlabel('Number of sensors');
ylabel('Signal reduction factor [dB]');

legend('Max. SNR','Wiener','MVDR','Location','NorthEast');
