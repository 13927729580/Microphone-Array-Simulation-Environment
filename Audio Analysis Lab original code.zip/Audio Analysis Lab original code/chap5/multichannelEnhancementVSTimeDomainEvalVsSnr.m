clc;clear all;close all;

addpath([cd,'\..\nonstationaryMultichanNoiseGenerator']);
addpath([cd,'\..\functions\']);

setup.sensorDistance = 0.1;
setup.speedOfSound = 343;
setup.nSensors = 3;
setup.noiseField = 'spherical';
setup.reverbTime = 0.2;

setup.sdnrGrid = -10:5:10;
setup.ssnr = 30;

setup.nWin = 80;
setup.forgetNoi = 0.8;
setup.forgetSig = 0.8;

setup.filtStrings = {'wiener','mvdr','maxSnr'};

display(['Running script: ',mfilename]);
display(' ');

display('Enhancing...');
for idx = 1:length(setup.sdnrGrid),
    setup.sdnr = setup.sdnrGrid(idx);
    [signals,setup] = multichannelSignalGenerator(setup);

    [simulationData,setup] = vsTimeDomEnhanceMultChanSignals(signals,setup);

    performance(idx,1) = vsTimeDomMultichannelMeasurePerformance(simulationData,setup,1);
end

%%
display('Measuring performance...');
for idx = 1:length(setup.sdnrGrid),
    iSnrMean(1,idx) = performance(idx,1).noiseReduction.iSnr.mean;
    oSnrMaxSnrMean(1,idx) = performance(idx,1).noiseReduction.oSnr.maxSnr.mean;
    oSnrWienerMean(1,idx) = performance(idx,1).noiseReduction.oSnr.wiener.mean;
    oSnrMvdrMean(1,idx) = performance(idx,1).noiseReduction.oSnr.mvdr.mean;

    dsdMaxSnrMean(1,idx) = performance(idx,1).signalDistortion.dsd.maxSnr.mean;
    dsdWienerMean(1,idx) = performance(idx,1).signalDistortion.dsd.wiener.mean;
    dsdMvdrMean(1,idx) = performance(idx,1).signalDistortion.dsd.mvdr.mean;
end

for idx = 1:length(setup.sdnrGrid),
    iSnrOverTime(:,idx) = performance(idx,1).noiseReduction.iSnr.overTime;
    oSnrMaxSnrOverTime(:,idx) = performance(idx,1).noiseReduction.oSnr.maxSnr.overTime;
    oSnrWienerOverTime(:,idx) = performance(idx,1).noiseReduction.oSnr.wiener.overTime;
    oSnrMvdrOverTime(:,idx) = performance(idx,1).noiseReduction.oSnr.mvdr.overTime;

    dsdMaxSnrOverTime(:,idx) = performance(idx,1).signalDistortion.dsd.maxSnr.overTime;
    dsdWienerOverTime(:,idx) = performance(idx,1).signalDistortion.dsd.wiener.overTime;
    dsdMvdrOverTime(:,idx) = performance(idx,1).signalDistortion.dsd.mvdr.overTime;
end

%% save
% dateString = datestr(now,30);
% 
% save([mfilename,'_',dateString,'.mat']);

%% plot
close all;
figure(1);
plot(10*log10(mean(iSnrMean,3)),'k');
hold on;
plot(10*log10(mean(oSnrMaxSnrMean,3)));
plot(10*log10(mean(oSnrWienerMean,3)));
plot(10*log10(mean(oSnrMvdrMean,3).'),'g');
hold off;

figure(2);
plot(10*log10(mean(dsdMaxSnrMean,3)));
hold on;
plot(10*log10(mean(dsdWienerMean,3)));
plot(10*log10(mean(dsdMvdrMean,3).'),'g');
hold off;

figure(3);
plot(10*log10(mean(iSnrOverTime,3)),'k');
hold on;
plot(10*log10(mean(oSnrMaxSnrOverTime,3)));
plot(10*log10(mean(oSnrWienerOverTime,3)));
plot(10*log10(mean(oSnrMvdrOverTime,3).'),'g');
hold off;

figure(4);
plot(10*log10(mean(dsdMaxSnrOverTime,3)));
hold on;
plot(10*log10(mean(dsdWienerOverTime,3)));
plot(10*log10(mean(dsdMvdrOverTime,3).'),'g');
hold off;
