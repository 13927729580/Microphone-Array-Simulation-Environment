function [data,setup] = vsTimeDomEnhanceMultChanSignals(signals,setup)

data.raw.sig = signals.clean;
data.raw.noi = signals.noise;
data.raw.obs = signals.observed;

% for iSens = 1:setup.nSensors,
%     % apply stft
%     [data.raw.sigStft(:,:,iSens),freqGrid,timeGrid,data.raw.sigBlocks(:,:,iSens)] ...
%         = stftBatch(signals.clean(:,iSens),setup.nWin,setup.nFft,setup.sampFreq);
%     [data.raw.noiStft(:,:,iSens),~,~,data.raw.noiBlocks(:,:,iSens)] ...
%         = stftBatch(signals.noise(:,iSens),setup.nWin,setup.nFft,setup.sampFreq);
%     [data.raw.obsStft(:,:,iSens),~,~,data.raw.obsBlocks(:,:,iSens)] ...
%         = stftBatch(signals.observed(:,iSens),setup.nWin,setup.nFft,setup.sampFreq);
% end
% [setup.nFreqs,setup.nFrames,~] = size(data.raw.sigStft);


noiCorr1 = eye(setup.nWin);
obsCorr1 = eye(setup.nWin);
sigCorr1 = eye(setup.nWin);

noiCorrAll = eye(setup.nWin*setup.nSensors);
sigMCorr = eye(setup.nWin*setup.nSensors);
sigICorr = eye(setup.nWin*setup.nSensors);

% noiCorrAll1 = eye(setup.nWin*setup.nSensors,setup.nWin);
% obsCorrAll1 = eye(setup.nWin*setup.nSensors,setup.nWin);
sigCorrAll1 = eye(setup.nWin*setup.nSensors,setup.nWin);

regulPar = 1e-6;

iter = 1;
frameNdx = 1:setup.nWin;
while frameNdx(end) <= size(data.raw.noi,1),
    
    noiBlock = data.raw.noi(frameNdx,:);
    sigBlock = data.raw.sig(frameNdx,:);
    obsBlock = data.raw.obs(frameNdx,:);
    
    noiCorr1 = (1-setup.forgetNoi)*noiCorr1 + (setup.forgetNoi)*(noiBlock(:,1)*noiBlock(:,1)');
    sigCorr1 = (1-setup.forgetSig)*sigCorr1 + (setup.forgetSig)*(sigBlock(:,1)*sigBlock(:,1)');

    if rank(sigCorr1)<setup.nWin,
        sigCorr1 = sigCorr1*(1-regulPar)+...
            (regulPar)*trace(sigCorr1)/(setup.nWin)*...
            eye(setup.nWin);
%             disp(['Warning! Noise correlation matrix is rank deficient (iFreq = ',num2str(iFreq),'.']);
%             keyboard;
    end
%     sigCorr1Reg = s
    
    
    obsCorr1 = (1-setup.forgetSig)*obsCorr1 + (setup.forgetSig)*(obsBlock(:,1)*obsBlock(:,1)');
    
    noiCorrAll = (1-setup.forgetNoi)*noiCorrAll + (setup.forgetNoi)*(noiBlock(:)*noiBlock(:)');
    
%     noiCorrAll1 = (1-setup.forgetNoi)*noiCorrAll1 + setup.forgetNoi*(noiBlock(:)*noiBlock(:,1)');
    sigCorrAll1 = (1-setup.forgetSig)*sigCorrAll1 + (setup.forgetSig)*(sigBlock(:)*sigBlock(:,1)');
%     obsCorrAll1 = (1-setup.forgetSig)*obsCorrAll1 + setup.forgetSig*(obsBlock(:)*obsBlock(:,1)');
    
    
    
    gamSig = sigCorrAll1/sigCorr1;
    sigM = gamSig*sigBlock(:,1);
    sigI = sigBlock(:) - sigM;
    
    sigMCorr = (1-setup.forgetSig)*sigMCorr + (setup.forgetSig)*(sigM*sigM');
    sigICorr = (1-setup.forgetSig)*sigICorr + (setup.forgetSig)*(sigI*sigI');
    intNoiCorr = sigICorr + noiCorrAll;
    
    if rank(intNoiCorr)<setup.nWin*setup.nSensors,
        intNoiCorr = intNoiCorr*(1-regulPar)+...
            (regulPar)*trace(intNoiCorr)/(setup.nWin*setup.nSensors)*...
            eye(setup.nWin*setup.nSensors);
%             disp(['Warning! Noise correlation matrix is rank deficient (iFreq = ',num2str(iFreq),'.']);
%             keyboard;
    end
    
    %GEVD
    [geigVec,geigVal] = jeig(sigMCorr,intNoiCorr,1);
    
    % filter signals
    data.raw.sigFrames(:,iter) = sigBlock(:,1);
    data.raw.obsFrames(:,iter) = obsBlock(:,1);
    data.raw.noiFrames(:,iter) = noiBlock(:,1);
    
    for iFiltStr=1:length(setup.filtStrings),
        switch char(setup.filtStrings(iFiltStr)),
            case 'maxSnr',
            % max snr filt
            HmaxSnr = sigCorr1*gamSig'*geigVec(:,1)*...
                (geigVal(1,1)\...
                geigVec(:,1)');
            % filtering
            data.maxSnr.sigFrames(:,iter) = HmaxSnr*sigBlock(:);
            data.maxSnr.obsFrames(:,iter) = HmaxSnr*obsBlock(:);
            data.maxSnr.noiFrames(:,iter) = HmaxSnr*noiBlock(:);
            
            case 'wiener',
             % wiener 
%             geigValTmp = geigVal(1:setup.nWin,1:setup.nWin);
%             if rank(geigValTmp)<setup.nWin,
%                 geigValTmp = geigValTmp*(1-regulPar)+...
%                     (regulPar)*trace(geigValTmp)/(setup.nWin)*...
%                     eye(setup.nWin);
%             end
            Hw = sigCorr1*gamSig'*geigVec(:,1:setup.nWin)*...
                ((eye(setup.nWin)+geigVal(1:setup.nWin,1:setup.nWin))\...
                geigVec(:,1:setup.nWin)');
            % filtering
            data.wiener.sigFrames(:,iter) = Hw*sigBlock(:);
            data.wiener.obsFrames(:,iter) = Hw*obsBlock(:);
            data.wiener.noiFrames(:,iter) = Hw*noiBlock(:);
            
            case 'mvdr',
            % mvdr
            geigValTmp = geigVal(1:setup.nWin,1:setup.nWin);
            if rank(geigValTmp)<setup.nWin,
                geigValTmp = geigValTmp*(1-regulPar)+...
                    (regulPar)*trace(geigValTmp)/(setup.nWin)*...
                    eye(setup.nWin);
            end
            Hmvdr = sigCorr1*gamSig'*geigVec(:,1:setup.nWin)*...
                ((geigValTmp)\...
                geigVec(:,1:setup.nWin)');
            % filtering 
            data.mvdr.sigFrames(:,iter) = Hmvdr*sigBlock(:);
            data.mvdr.obsFrames(:,iter) = Hmvdr*obsBlock(:);
            data.mvdr.noiFrames(:,iter) = Hmvdr*noiBlock(:);
            
            case 'trOff',
            % trade off
%             blb = zeros(setup.nWin*setup.nSensors);
%             iterRanks = 1;
%             
%             geigValTmp = geigVal(1:max(setup.trOff.signalRanks),...
%                 1:max(setup.trOff.signalRanks));
%             if rank(geigValTmp)<max(setup.trOff.signalRanks),
%                 geigValTmp = geigValTmp*(1-regulPar)+...
%                     (regulPar)*trace(geigValTmp)/(max(setup.trOff.signalRanks))*...
%                     eye(max(setup.trOff.signalRanks));
%             end
%             for iRanks = 1:max(setup.trOff.signalRanks),
%                 blb = blb + geigVec(:,iRanks)*...
%                 ((setup.trOff.mu+geigValTmp(iRanks,iRanks))^(-1)*...
%                 geigVec(:,iRanks)');
%                 if sum(iRanks==setup.trOff.signalRanks),
%                     HtrOff(:,:,iterRanks) = sigCorr1*gamSig'*blb;
%                     iterRanks = iterRanks + 1;
%                 end
%             end
            
            for iRanks = 1:length(setup.trOff.signalRanks),
                geigValTmp = geigVal(1:setup.trOff.signalRanks(iRanks),...
                1:setup.trOff.signalRanks(iRanks));
                if rank(geigValTmp)<setup.nWin,
                    geigValTmp = geigValTmp*(1-regulPar)+...
                        (regulPar)*trace(geigValTmp)/setup.trOff.signalRanks(iRanks)*...
                        eye(setup.trOff.signalRanks(iRanks));
                end
                HtrOff(:,:,iRanks) = sigCorr1*gamSig'*...
                    geigVec(:,1:setup.trOff.signalRanks(iRanks))*...
                ((setup.trOff.mu*eye(setup.trOff.signalRanks(iRanks))+geigValTmp)\...
                geigVec(:,1:setup.trOff.signalRanks(iRanks))');
            end
            
            % filtering 
            for iRanks = 1:length(setup.trOff.signalRanks),
                data.trOff.sigFrames(:,iter,iRanks) = HtrOff(:,:,iRanks)*sigBlock(:);
                data.trOff.obsFrames(:,iter,iRanks) = HtrOff(:,:,iRanks)*obsBlock(:);
                data.trOff.noiFrames(:,iter,iRanks) = HtrOff(:,:,iRanks)*noiBlock(:);
            end
        end
    end
%     sigMCorr

    %%
%     close all;
%     plot(sigBlock(:,1));
%     hold on;
%     plot(obsBlock(:,1),'g');
%     plot(data.wiener.obsFrames(:,iter),'r');
%     hold off;
%     %%
%     pause;

    frameNdx = frameNdx + setup.nWin/2;
    iter = iter + 1;
     % estimate statistics
%         noiCorr(:,:,iFreq) = (1-setup.forgetNoi)*noiCorr(:,:,iFreq) + setup.forgetNoi*(noiBlock*noiBlock');
%     
end

for iFiltStr=1:length(setup.filtStrings),
    switch char(setup.filtStrings(iFiltStr)),
        case 'maxSnr',
        data.maxSnr.sig = mergeSignalFrames(data.maxSnr.sigFrames);
        data.maxSnr.obs = mergeSignalFrames(data.maxSnr.obsFrames);
        data.maxSnr.noi = mergeSignalFrames(data.maxSnr.noiFrames);   
        case 'wiener',
        data.wiener.sig = mergeSignalFrames(data.wiener.sigFrames);
        data.wiener.obs = mergeSignalFrames(data.wiener.obsFrames);
        data.wiener.noi = mergeSignalFrames(data.wiener.noiFrames);
        case 'mvdr',
        data.mvdr.sig = mergeSignalFrames(data.mvdr.sigFrames);
        data.mvdr.obs = mergeSignalFrames(data.mvdr.obsFrames);
        data.mvdr.noi = mergeSignalFrames(data.mvdr.noiFrames);
        case 'trOff',
        for iRanks = 1:length(setup.trOff.signalRanks),
            data.trOff.sig(:,iRanks) = mergeSignalFrames(data.trOff.sigFrames(:,:,iRanks));
            data.trOff.obs(:,iRanks) = mergeSignalFrames(data.trOff.obsFrames(:,:,iRanks));
            data.trOff.noi(:,iRanks) = mergeSignalFrames(data.trOff.noiFrames(:,:,iRanks)); 
        end
    end
end

% function signalFrames = splitSignalIntoFrames(signal,blockLength)
%     ndx = 1:blockLength;
%     loopNo = 1;
%     while ndx(end)<=size(signal,1),
%         signalFrames(:,:,loopNo) = signal(ndx,:);
%         loopNo = loopNo + 1;
%         
%         ndx = ndx + blockLength/2;
%     end
% end
% 
end

function signal = mergeSignalFrames(signalFrames)
    frameLength = size(signalFrames,1);
%     nChan = size(signalFrame,2);
    nFrames = size(signalFrames,2);
    signal = zeros((nFrames+1)*frameLength/2,1);
    
    window = hanning(frameLength,'periodic');
    
    prevFrameEnd = zeros(frameLength,1);
    ndx = 1:frameLength;
    for ii = 1:nFrames,
        
        thisFrame = prevFrameEnd + window.*signalFrames(:,ii);
        signal(ndx,1) = thisFrame;
        
        prevFrameEnd = [thisFrame(frameLength/2+1:end,1);...
            zeros(frameLength/2,1);];
        ndx = ndx + frameLength/2;
        
        
    end
end
    
%     for iFreq=1:setup.nFreqs,
%         noiBlock = zeros(setup.nFilt*setup.nSensors,1);
%         sigBlock = zeros(setup.nFilt*setup.nSensors,1);
%         obsBlock = zeros(setup.nFilt*setup.nSensors,1);
%         for iSens = 1:setup.nSensors,
%             if iFrame<setup.nFilt,
%                 noiBlock((1:setup.nFilt)+(iSens-1)*setup.nFilt,1) ...
%                     = [data.raw.noiStft(iFreq,iFrame:-1:1,iSens).';zeros(setup.nFilt-iFrame,1)];
%                 sigBlock((1:setup.nFilt)+(iSens-1)*setup.nFilt,1) ...
%                     = [data.raw.sigStft(iFreq,iFrame:-1:1,iSens).';zeros(setup.nFilt-iFrame,1)];
%                 obsBlock((1:setup.nFilt)+(iSens-1)*setup.nFilt,1) ... 
%                     = [data.raw.obsStft(iFreq,iFrame:-1:1,iSens).';zeros(setup.nFilt-iFrame,1)];
%             else
%                 noiBlock((1:setup.nFilt)+(iSens-1)*setup.nFilt,1) ...
%                     = data.raw.noiStft(iFreq,iFrame:-1:iFrame-setup.nFilt+1,iSens).';
%                 sigBlock((1:setup.nFilt)+(iSens-1)*setup.nFilt,1) ...
%                     = data.raw.sigStft(iFreq,iFrame:-1:iFrame-setup.nFilt+1,iSens).';
%                 obsBlock((1:setup.nFilt)+(iSens-1)*setup.nFilt,1) ...
%                     = data.raw.obsStft(iFreq,iFrame:-1:iFrame-setup.nFilt+1,iSens).';
%             end 
%         end
% 
%         % estimate statistics
%         noiCorr(:,:,iFreq) = (1-setup.forgetNoi)*noiCorr(:,:,iFreq) + setup.forgetNoi*(noiBlock*noiBlock');
%         obsCorr(:,:,iFreq) = (1-setup.forgetSig)*obsCorr(:,:,iFreq) + setup.forgetSig*(obsBlock*obsBlock');
%         sigCorr(:,:,iFreq) = (1-setup.forgetSig)*sigCorr(:,:,iFreq) + setup.forgetSig*(sigBlock*sigBlock');
%         for iFilt = 1:setup.nSensors*setup.nFilt,
%             noiCorr(iFilt,iFilt,iFreq) = real(noiCorr(iFilt,iFilt,iFreq));
%             obsCorr(iFilt,iFilt,iFreq) = real(obsCorr(iFilt,iFilt,iFreq));
%             sigCorr(iFilt,iFilt,iFreq) = real(sigCorr(iFilt,iFilt,iFreq));
%         end  
%         
% %         if iFreq == 20,
% %         plot(abs(sigCorr(:,1,iFreq)));
% %         drawnow;
% %         end
%         
% %         if iFreq==1,
% %            noiBlock
% %            pause
% % %            keyboard; 
% %         end
%         regulPar = 1e-6;
%         if rank(noiCorr(:,:,iFreq))<setup.nSensors*setup.nFilt,
%             noiCorr(:,:,iFreq) = noiCorr(:,:,iFreq)*(1-regulPar)+...
%                 (regulPar)*trace(noiCorr(:,:,iFreq))/(setup.nFilt*setup.nSensors)*...
%                 eye(setup.nFilt*setup.nSensors);
% %             disp(['Warning! Noise correlation matrix is rank deficient (iFreq = ',num2str(iFreq),'.']);
% %             keyboard;
%         end
%         
%         % joint diagonalization
%         [geigVec(:,:,iFreq),geigVal(:,:,iFreq)] = jeig(sigCorr(:,:,iFreq),...
%             noiCorr(:,:,iFreq),1);
% 
%         for iFiltStr=1:length(setup.filtStrings),
%             switch char(setup.filtStrings(iFiltStr)),
%                 case 'maxSnr',
%                 % max snr filt
%                 hMaxSnr(:,iFreq) = (geigVec(:,1,iFreq)*geigVec(:,1,iFreq)')/geigVal(1,1,iFreq)*sigCorr(:,1,iFreq);
%                 if norm(hMaxSnr(:,iFreq))==0,
%                     hMaxSnr(:,iFreq) = eye(setup.nFilt,1);
%                 end                
%                 data.maxSnr.sigStft(iFreq,iFrame) = hMaxSnr(:,iFreq)'*sigBlock;
%                 data.maxSnr.noiStft(iFreq,iFrame) = hMaxSnr(:,iFreq)'*noiBlock;
%                 data.maxSnr.obsStft(iFreq,iFrame) = hMaxSnr(:,iFreq)'*obsBlock;
% %                 data.maxSnr.sigPow(iFreq,iFrame) = real(hMaxSnr(:,iFreq)'*sigCorr(:,:,iFreq)*hMaxSnr(:,iFreq));
% %                 data.maxSnr.noiPow(iFreq,iFrame) = real(hMaxSnr(:,iFreq)'*noiCorr(:,:,iFreq)*hMaxSnr(:,iFreq));
% %                 data.maxSnr.obsPow(iFreq,iFrame) = real(hMaxSnr(:,iFreq)'*obsCorr(:,:,iFreq)*hMaxSnr(:,iFreq));
%                 
%                 case 'wiener',
%                 % wiener filt
%                 blbSubW = zeros(setup.nFilt*setup.nSensors);
%                 for iFilt = 1:setup.nFilt,
%                     blbSubW = blbSubW + (geigVec(:,iFilt,iFreq)*geigVec(:,iFilt,iFreq)')...
%                         /(1+geigVal(iFilt,iFilt,iFreq));
%                 end
%                 hWiener(:,iFreq) = blbSubW*sigCorr(:,1,iFreq);
%                 
%                 
%                 if norm(hWiener(:,iFreq))==0,
%                     hWiener(:,iFreq) = eye(setup.nFilt,1);
%                 end
%                 data.wiener.sigStft(iFreq,iFrame) = hWiener(:,iFreq)'*sigBlock;
%                 data.wiener.noiStft(iFreq,iFrame) = hWiener(:,iFreq)'*noiBlock;
%                 data.wiener.obsStft(iFreq,iFrame) = hWiener(:,iFreq)'*obsBlock;
%                 
%                 case 'minDis',
%                 % minimum dist filt
%                 blbSub = zeros(setup.nFilt*setup.nSensors);
%                 iterRanks = 1;
%                 for iRanks = 1:max(setup.minDis.signalRanks),
%                     blbSub = blbSub + (geigVec(:,iRanks,iFreq)*geigVec(:,iRanks,iFreq)')/geigVal(iRanks,iRanks,iFreq);
%                     if sum(iRanks==setup.minDis.signalRanks),
%                         hMinDis(:,iFreq,iterRanks) = blbSub*sigCorr(:,1,iFreq);
%                         if norm(hMinDis(:,iFreq,iterRanks))==0,
%                             hMinDis(:,iFreq,iterRanks) = eye(setup.nFilt,1);
%                         end
%                         iterRanks = iterRanks + 1;
%                     end
%                 end
%                 for iRanks=1:length(setup.minDis.signalRanks),
%                     data.minDis.sigStft(iFreq,iFrame,iRanks) = hMinDis(:,iFreq,iRanks)'*sigBlock;
%                     data.minDis.noiStft(iFreq,iFrame,iRanks) = hMinDis(:,iFreq,iRanks)'*noiBlock;
%                     data.minDis.obsStft(iFreq,iFrame,iRanks) = hMinDis(:,iFreq,iRanks)'*obsBlock;
% %                     data.minDis.sigPow(iFreq,iFrame,iRanks) = real(hMinDis(:,iFreq,iRanks)'*sigCorr(:,:,iFreq)*hMinDis(:,iFreq,iRanks));
% %                     data.minDis.noiPow(iFreq,iFrame,iRanks) = real(hMinDis(:,iFreq,iRanks)'*noiCorr(:,:,iFreq)*hMinDis(:,iFreq,iRanks));
% %                     data.minDis.obsPow(iFreq,iFrame,iRanks) = real(hMinDis(:,iFreq,iRanks)'*obsCorr(:,:,iFreq)*hMinDis(:,iFreq,iRanks));
%                 end
%                 case 'trOff',
%                 % trade off filt
%                 blbSub = zeros(setup.nFilt*setup.nSensors);
%                 iterRanks = 1;
%                 for iRanks = 1:max(setup.trOff.signalRanks),
%                     blbSub = blbSub + (geigVec(:,iRanks,iFreq)*geigVec(:,iRanks,iFreq)')/(setup.trOff.mu+geigVal(iRanks,iRanks,iFreq));
%                     if sum(iRanks==setup.trOff.signalRanks),
%                         hTrOff(:,iFreq,iterRanks) = blbSub*sigCorr(:,1,iFreq);
%                         if norm(hTrOff(:,iFreq,iterRanks))==0,
%                             hTrOff(:,iFreq,iterRanks) = eye(setup.nFilt,1);
%                         end
%                         iterRanks = iterRanks + 1;
%                     end
%                 end
%                 for iRanks=1:length(setup.trOff.signalRanks),
%                     data.trOff.sigStft(iFreq,iFrame,iRanks) = hTrOff(:,iFreq,iRanks)'*sigBlock;
%                     data.trOff.noiStft(iFreq,iFrame,iRanks) = hTrOff(:,iFreq,iRanks)'*noiBlock;
%                     data.trOff.obsStft(iFreq,iFrame,iRanks) = hTrOff(:,iFreq,iRanks)'*obsBlock;
%                     data.trOff.sigPow(iFreq,iFrame,iRanks) = real(hTrOff(:,iFreq,iRanks)'*sigCorr(:,:,iFreq)*hTrOff(:,iFreq,iRanks));
%                     data.trOff.noiPow(iFreq,iFrame,iRanks) = real(hTrOff(:,iFreq,iRanks)'*noiCorr(:,:,iFreq)*hTrOff(:,iFreq,iRanks));
%                     data.trOff.obsPow(iFreq,iFrame,iRanks) = real(hTrOff(:,iFreq,iRanks)'*obsCorr(:,:,iFreq)*hTrOff(:,iFreq,iRanks));
%                 end
%             end
%         end
%     end
% end
% 
% for iFiltStr=1:length(setup.filtStrings),
%     switch char(setup.filtStrings(iFiltStr)),
%         case 'maxSnr',
%         data.maxSnr.sig = stftInvBatch(data.maxSnr.sigStft,setup.nWin,setup.nFft);
%         data.maxSnr.noi = stftInvBatch(data.maxSnr.noiStft,setup.nWin,setup.nFft);
%         data.maxSnr.obs = stftInvBatch(data.maxSnr.obsStft,setup.nWin,setup.nFft);
%         case 'wiener',
%         data.wiener.sig = stftInvBatch(data.wiener.sigStft,setup.nWin,setup.nFft);
%         data.wiener.noi = stftInvBatch(data.wiener.noiStft,setup.nWin,setup.nFft);
%         data.wiener.obs = stftInvBatch(data.wiener.obsStft,setup.nWin,setup.nFft);
%         case 'minDis',
%         for iRanks=1:length(setup.minDis.signalRanks),
%             data.minDis.sig(:,iRanks) = stftInvBatch(data.minDis.sigStft(:,:,iRanks),setup.nWin,setup.nFft);
%             data.minDis.noi(:,iRanks) = stftInvBatch(data.minDis.noiStft(:,:,iRanks),setup.nWin,setup.nFft);
%             data.minDis.obs(:,iRanks) = stftInvBatch(data.minDis.obsStft(:,:,iRanks),setup.nWin,setup.nFft);
%         end
%         case 'trOff',
%         for iRanks=1:length(setup.trOff.signalRanks),
%             data.trOff.sig(:,iRanks) = stftInvBatch(data.trOff.sigStft(:,:,iRanks),setup.nWin,setup.nFft);
%             data.trOff.noi(:,iRanks) = stftInvBatch(data.trOff.noiStft(:,:,iRanks),setup.nWin,setup.nFft);
%             data.trOff.obs(:,iRanks) = stftInvBatch(data.trOff.obsStft(:,:,iRanks),setup.nWin,setup.nFft);
%         end
%     end
% end
% 
% % save setup
% setup.stftFreqGrid = freqGrid;
% setup.stftTimeGrid = timeGrid;
% % setup.freqSamp = freqSamp;
% 
% % break;
% 
% 
% % inits
% % noiCorr = repmat(eye(nFilt),1,1,nFreqs);
% % obsCorr = repmat(eye(nFilt),1,1,nFreqs);
% % sigCorr = repmat(eye(nFilt),1,1,nFreqs);
% % geigVec = zeros(nFilt,nFilt,nFreqs);
% % geigVal = zeros(nFilt,nFilt,nFreqs);
% % for iFiltStrs = 1:length(filtStrings),
% %     switch char(filtStrings(iFiltStrs)),
% %         case 'maxSnr',
% %         hMaxSnr = zeros(nFilt,nFreqs);
% %         data.maxSnr.sigStft = zeros(nFreqs,nFrames);
% %         data.maxSnr.noiStft = zeros(nFreqs,nFrames);
% %         data.maxSnr.obsStft = zeros(nFreqs,nFrames);
% %         case 'wiener',
% %         hWiener = zeros(nFilt,nFreqs);
% %         data.wiener.sigStft = zeros(nFreqs,nFrames);
% %         data.wiener.noiStft = zeros(nFreqs,nFrames);
% %         data.wiener.obsStft = zeros(nFreqs,nFrames);
% %         case 'minDis', 
% %         hMinDis = zeros(nFilt,nFreqs,length(filtSetups.minDis.signalRanks));
% %         data.minDis.sigStft = zeros(nFreqs,nFrames,length(filtSetups.minDis.signalRanks));
% %         data.minDis.noiStft = zeros(nFreqs,nFrames,length(filtSetups.minDis.signalRanks));
% %         data.minDis.obsStft = zeros(nFreqs,nFrames,length(filtSetups.minDis.signalRanks));
% %         case 'trOff', 
% %         hTrOff = zeros(nFilt,nFreqs,length(filtSetups.trOff.signalRanks));
% %         data.trOff.sigStft = zeros(nFreqs,nFrames,length(filtSetups.trOff.signalRanks));
% %         data.trOff.noiStft = zeros(nFreqs,nFrames,length(filtSetups.trOff.signalRanks));
% %         data.trOff.obsStft = zeros(nFreqs,nFrames,length(filtSetups.trOff.signalRanks));
% %     end
% % end
% % for iFrame=1:nFrames,
% %     for iFreq=1:nFreqs,
% %         % extract blocks from signal, noise and observation
% % %         iFrame
% %         if iFrame<nFilt,
% %             noiBlock = [data.raw.noiStft(iFreq,iFrame:-1:1).';zeros(nFilt-iFrame,1)];
% %             sigBlock = [data.raw.sigStft(iFreq,iFrame:-1:1).';zeros(nFilt-iFrame,1)];
% %             obsBlock = [data.raw.obsStft(iFreq,iFrame:-1:1).';zeros(nFilt-iFrame,1)];
% %         else
% %             noiBlock = data.raw.noiStft(iFreq,iFrame:-1:iFrame-nFilt+1).';
% %             sigBlock = data.raw.sigStft(iFreq,iFrame:-1:iFrame-nFilt+1).';
% %             obsBlock = data.raw.obsStft(iFreq,iFrame:-1:iFrame-nFilt+1).';
% %         end        
% %         
% %         % estimate statistics
% %         noiCorr(:,:,iFreq) = (1-forgetNoi)*noiCorr(:,:,iFreq) + forgetNoi*(noiBlock*noiBlock');
% %         obsCorr(:,:,iFreq) = (1-forgetSig)*obsCorr(:,:,iFreq) + forgetSig*(obsBlock*obsBlock');
% %         sigCorr(:,:,iFreq) = (1-forgetSig)*sigCorr(:,:,iFreq) + forgetSig*(sigBlock*sigBlock');
% %         
% %         for iFilt = 1:nFilt,
% %             noiCorr(iFilt,iFilt,iFreq) = real(noiCorr(iFilt,iFilt,iFreq));
% %             obsCorr(iFilt,iFilt,iFreq) = real(obsCorr(iFilt,iFilt,iFreq));
% %             sigCorr(iFilt,iFilt,iFreq) = real(sigCorr(iFilt,iFilt,iFreq));
% %         end  
% %         
% %         % save power
% %         data.raw.sigPow(iFreq,iFrame) = real(sigCorr(1,1,iFreq));
% %         data.raw.noiPow(iFreq,iFrame) = real(noiCorr(1,1,iFreq));
% %         data.raw.obsPow(iFreq,iFrame) = real(obsCorr(1,1,iFreq));
% %         
% %         % joint diagonalization
% %         [geigVec(:,:,iFreq),geigVal(:,:,iFreq)] = jeig(sigCorr(:,:,iFreq),...
% %             noiCorr(:,:,iFreq),1);
% %         
% %         for iFiltStr=1:length(filtStrings),
% %             switch char(filtStrings(iFiltStr)),
% %                 case 'maxSnr',
% %                 % max snr filt
% %                 hMaxSnr(:,iFreq) = (geigVec(:,1,iFreq)*geigVec(:,1,iFreq)')/geigVal(1,1,iFreq)*sigCorr(:,1,iFreq);
% %                 if norm(hMaxSnr(:,iFreq))==0,
% %                     hMaxSnr(:,iFreq) = eye(nFilt,1);
% %                 end                
% %                 data.maxSnr.sigStft(iFreq,iFrame) = hMaxSnr(:,iFreq)'*sigBlock;
% %                 data.maxSnr.noiStft(iFreq,iFrame) = hMaxSnr(:,iFreq)'*noiBlock;
% %                 data.maxSnr.obsStft(iFreq,iFrame) = hMaxSnr(:,iFreq)'*obsBlock;
% %                 data.maxSnr.sigPow(iFreq,iFrame) = real(hMaxSnr(:,iFreq)'*sigCorr(:,:,iFreq)*hMaxSnr(:,iFreq));
% %                 data.maxSnr.noiPow(iFreq,iFrame) = real(hMaxSnr(:,iFreq)'*noiCorr(:,:,iFreq)*hMaxSnr(:,iFreq));
% %                 data.maxSnr.obsPow(iFreq,iFrame) = real(hMaxSnr(:,iFreq)'*obsCorr(:,:,iFreq)*hMaxSnr(:,iFreq));
% %                 
% %                 case 'wiener',
% %                 % wiener filt
% %                 blbSubW = zeros(nFilt);
% %                 for iFilt = 1:nFilt,
% %                     blbSubW = blbSubW + (geigVec(:,iFilt,iFreq)*geigVec(:,iFilt,iFreq)')...
% %                         /(1+geigVal(iFilt,iFilt,iFreq));
% %                 end
% %                 hWiener(:,iFreq) = blbSubW*sigCorr(:,1,iFreq);
% %                 if norm(hWiener(:,iFreq))==0,
% %                     hWiener(:,iFreq) = eye(nFilt,1);
% %                 end
% %                 data.wiener.sigStft(iFreq,iFrame) = hWiener(:,iFreq)'*sigBlock;
% %                 data.wiener.noiStft(iFreq,iFrame) = hWiener(:,iFreq)'*noiBlock;
% %                 data.wiener.obsStft(iFreq,iFrame) = hWiener(:,iFreq)'*obsBlock;
% %                 data.wiener.sigPow(iFreq,iFrame) = real(hWiener(:,iFreq)'*sigCorr(:,:,iFreq)*hWiener(:,iFreq));
% %                 data.wiener.noiPow(iFreq,iFrame) = real(hWiener(:,iFreq)'*noiCorr(:,:,iFreq)*hWiener(:,iFreq));
% %                 data.wiener.obsPow(iFreq,iFrame) = real(hWiener(:,iFreq)'*obsCorr(:,:,iFreq)*hWiener(:,iFreq));
% % 
% %                 case 'minDis',
% %                 % minimum dist filt
% %                 blbSub = zeros(nFilt);
% %                 iterRanks = 1;
% %                 for iRanks = 1:max(filtSetups.minDis.signalRanks),
% %                     blbSub = blbSub + (geigVec(:,iRanks,iFreq)*geigVec(:,iRanks,iFreq)')/geigVal(iRanks,iRanks,iFreq);
% %                     if sum(iRanks==filtSetups.minDis.signalRanks),
% %                         hMinDis(:,iFreq,iterRanks) = blbSub*sigCorr(:,1,iFreq);
% %                         if norm(hMinDis(:,iFreq,iterRanks))==0,
% %                             hMinDis(:,iFreq,iterRanks) = eye(nFilt,1);
% %                         end
% %                         iterRanks = iterRanks + 1;
% %                     end
% %                 end
% %                 for iRanks=1:length(filtSetups.minDis.signalRanks),
% %                     data.minDis.sigStft(iFreq,iFrame,iRanks) = hMinDis(:,iFreq,iRanks)'*sigBlock;
% %                     data.minDis.noiStft(iFreq,iFrame,iRanks) = hMinDis(:,iFreq,iRanks)'*noiBlock;
% %                     data.minDis.obsStft(iFreq,iFrame,iRanks) = hMinDis(:,iFreq,iRanks)'*obsBlock;
% %                     data.minDis.sigPow(iFreq,iFrame,iRanks) = real(hMinDis(:,iFreq,iRanks)'*sigCorr(:,:,iFreq)*hMinDis(:,iFreq,iRanks));
% %                     data.minDis.noiPow(iFreq,iFrame,iRanks) = real(hMinDis(:,iFreq,iRanks)'*noiCorr(:,:,iFreq)*hMinDis(:,iFreq,iRanks));
% %                     data.minDis.obsPow(iFreq,iFrame,iRanks) = real(hMinDis(:,iFreq,iRanks)'*obsCorr(:,:,iFreq)*hMinDis(:,iFreq,iRanks));
% %                 end
% %                 
% %                 case 'trOff',
% %                 % trade off filt
% %                 blbSub = zeros(nFilt);
% %                 iterRanks = 1;
% %                 for iRanks = 1:max(filtSetups.trOff.signalRanks),
% %                     blbSub = blbSub + (geigVec(:,iRanks,iFreq)*geigVec(:,iRanks,iFreq)')/(filtSetups.trOff.mu+geigVal(iRanks,iRanks,iFreq));
% %                     if sum(iRanks==filtSetups.trOff.signalRanks),
% %                         hTrOff(:,iFreq,iterRanks) = blbSub*sigCorr(:,1,iFreq);
% %                         if norm(hTrOff(:,iFreq,iterRanks))==0,
% %                             hTrOff(:,iFreq,iterRanks) = eye(nFilt,1);
% %                         end
% %                         iterRanks = iterRanks + 1;
% %                     end
% %                 end
% %                 for iRanks=1:length(filtSetups.trOff.signalRanks),
% %                     data.trOff.sigStft(iFreq,iFrame,iRanks) = hTrOff(:,iFreq,iRanks)'*sigBlock;
% %                     data.trOff.noiStft(iFreq,iFrame,iRanks) = hTrOff(:,iFreq,iRanks)'*noiBlock;
% %                     data.trOff.obsStft(iFreq,iFrame,iRanks) = hTrOff(:,iFreq,iRanks)'*obsBlock;
% %                     data.trOff.sigPow(iFreq,iFrame,iRanks) = real(hTrOff(:,iFreq,iRanks)'*sigCorr(:,:,iFreq)*hTrOff(:,iFreq,iRanks));
% %                     data.trOff.noiPow(iFreq,iFrame,iRanks) = real(hTrOff(:,iFreq,iRanks)'*noiCorr(:,:,iFreq)*hTrOff(:,iFreq,iRanks));
% %                     data.trOff.obsPow(iFreq,iFrame,iRanks) = real(hTrOff(:,iFreq,iRanks)'*obsCorr(:,:,iFreq)*hTrOff(:,iFreq,iRanks));
% %                 end
% %             end
% %         end
% %     end
% % end
% % 
% % for iFiltStr=1:length(filtStrings),
% %     switch char(filtStrings(iFiltStr)),
% %         case 'maxSnr',
% %         % stft to time
% %         data.maxSnr.sig = stftInvBatch(data.maxSnr.sigStft,nWin,nFft);
% %         data.maxSnr.noi = stftInvBatch(data.maxSnr.noiStft,nWin,nFft);
% %         data.maxSnr.obs = stftInvBatch(data.maxSnr.obsStft,nWin,nFft);
% %         
% % %         data.maxSnr.sigStftNoWin = stftInvBatch(data.maxSnr.sigStft,nWin,nFft);
% % %         data.maxSnr.noiStftNoWin = stftInvBatch(data.maxSnr.noiStft,nWin,nFft);
% % %         data.maxSnr.obsStftNoWin = stftInvBatch(data.maxSnr.obsStft,nWin,nFft);
% % 
% %         case 'wiener',
% %         data.wiener.sig = stftInvBatch(data.wiener.sigStft,nWin,nFft);
% %         data.wiener.noi = stftInvBatch(data.wiener.noiStft,nWin,nFft);
% %         data.wiener.obs = stftInvBatch(data.wiener.obsStft,nWin,nFft);
% % 
% %         case 'minDis',
% %         for iRanks=1:length(filtSetups.minDis.signalRanks),
% %             data.minDis.sig(:,iRanks) = stftInvBatch(data.minDis.sigStft(:,:,iRanks),nWin,nFft);
% %             data.minDis.noi(:,iRanks) = stftInvBatch(data.minDis.noiStft(:,:,iRanks),nWin,nFft);
% %             data.minDis.obs(:,iRanks) = stftInvBatch(data.minDis.obsStft(:,:,iRanks),nWin,nFft);
% %         end
% %         % save to struct
% %         data.minDis.signalRanks = filtSetups.minDis.signalRanks;
% %         
% %         case 'trOff',
% %         for iRanks=1:length(filtSetups.trOff.signalRanks),
% %             data.trOff.sig(:,iRanks) = stftInvBatch(data.trOff.sigStft(:,:,iRanks),nWin,nFft);
% %             data.trOff.noi(:,iRanks) = stftInvBatch(data.trOff.noiStft(:,:,iRanks),nWin,nFft);
% %             data.trOff.obs(:,iRanks) = stftInvBatch(data.trOff.obsStft(:,:,iRanks),nWin,nFft);
% %         end
% %         % save to struct
% %         data.trOff.signalRanks = filtSetups.trOff.signalRanks;
% %     end
% % end
% % 
% % % save setup
% % data.setup.stftFreqGrid = freqGrid;
% % data.setup.stftTimeGrid = timeGrid;
% % data.setup.freqSamp = freqSamp;
% % data.setup.nWin = nWin;
% % data.setup.nFft = nFft;
% % 
% % % save raw signals
% % data.raw.sig = signal;
% % data.raw.noi = noise;
% % data.raw.obs = observed;