

%-------------------------------------------------------------------------------------------------
%      Firstly, Great thanks to the Audio analysis Lab of Aalborg University, 
% they share the source code for the microphone environments simultaion, which will make 
% contribute to bulid the microphone array test environment for those do not have actual
% testing envirorment. And the website of its lab is: https://audio.create.aau.dk/
%
%	  Sencondly, I sligthly modified the origianl code and make them run easily, 
% and i am a master candidate of Harbin Institute of Technology, shenzhen. I will
% feel very honor, if we can discuss some questions about the reaserch about 
% microphone array processing, speech enhancement, deep learning. My Email is:
% zhanglu_wind@163.com
%
%     Finally, weclome for your great suggestion on the improvemnet of this code.
%
% How to use:
%
% The main funtion is the multichannelSignalGenerator() in ..\functions\multichannelSignalGenerator.m
% You can just run this function directly. ~ ~
%
%
% Author: Wind
% 
%
%------------------------------------------------------------------------------------------------